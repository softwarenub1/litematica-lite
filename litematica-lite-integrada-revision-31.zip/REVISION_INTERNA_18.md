# Revisión interna 18 — Política explícita de tareas

## Cambio aplicado

Se sustituyó en `scheduler/TaskScheduler.java` el bloqueo por prefijos de nombre (`TaskPaste`, `TaskDelete`, `TaskFill`, `TaskReplace`) por una **lista cerrada de clases exactas** admitidas:

- `TaskCountBlocksArea` — análisis de materiales por área.
- `TaskCountBlocksPlacement` — análisis de materiales por placement.
- `TaskSaveSchematic` — guardado de esquemas.
- `SchematicVerifier` — verificación de esquemas.

Cualquier otra implementación de `ITask`, incluida `TaskDelay`, es rechazada al solicitar su programación, tanto en el scheduler de cliente como en el del servidor integrado. Se evita que una subclase desconocida herede automáticamente permiso.

## Comprobaciones estáticas

Se revisaron los sitios `scheduleTask(...)` encontrados en el árbol de código. Las tareas de materiales, verificación y guardado coinciden con las cuatro clases admitidas. Las rutas de pegado y borrado en `SchematicUtils`, y la exportación de comandos de pegado, quedan rechazadas por el scheduler aunque sigan presentes en el código. Los métodos `runTasks()` y `addNewTasks()` no se modificaron.

## Limitaciones y pendientes

- **No compilado ni probado en Minecraft.** No se garantiza que todas las rutas de análisis funcionen hasta realizar pruebas.
- La política cubre solamente tareas que pasan por `TaskScheduler`, no operaciones directas, red/Servux, ni el planificador independiente `PlacementManagerDaemonHandler`.
- Aún deben eliminarse de interfaz las acciones prohibidas y revisarse llamadas directas a operaciones de mundo.
- El código de tareas prohibidas sigue en el árbol; su inaccesibilidad completa no está demostrada.

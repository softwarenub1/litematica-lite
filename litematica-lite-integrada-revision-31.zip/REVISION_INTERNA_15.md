# Revisión interna 15 — Menú de proyectos

**Cambios locales aplicados, sin compilación ni prueba funcional.**

En `GuiSchematicProjectManager.java` se retiraron los botones `PLACE_TO_WORLD` y `DELETE_AREA`, sus ramas de eventos, entradas del enum, ejecutores de confirmación y dependencias de importación asociadas.

Esto evita que el menú de proyectos ofrezca operaciones de pegar o borrar. No implica que todas las demás interfaces o puntos de entrada del mod estén limpios.

Verificación estática: no quedan referencias a `PLACE_TO_WORLD` ni `DELETE_AREA` en este archivo.

**Pendiente:** búsqueda global de botones y rutas similares, compilación y pruebas en cliente Minecraft.

# Revisión interna 23 — Transición a modo exclusivamente local

## Cambios aplicados en la copia de trabajo

- `EntityDataManager.onGameInit()` ya no registra el canal/codec Servux ni el controlador de paquetes.
- `EntityDataManager.onWorldPre()` ya no registra el receptor Servux.
- `EntityDataManager.onClientTick()` deja de procesar la cola de solicitudes NBT remotas y la vacía. No inicia negociaciones Servux ni consultas `query` en el ciclo de ticks.
- `EntityDataManager.isEnabled()` y `isBackupEnabled()` devuelven `false`.
- Se retiraron de la lista visible `Configs.Generic.OPTIONS` las entradas `ENTITY_DATA_SYNC`, `ENTITY_DATA_SYNC_BACKUP`, `ENTITY_DATA_SYNC_CACHE_TIMEOUT` y `SERVER_NBT_REQUEST_RATE`.
- Se retiró `ENTITY_DATA_SYNC` de la lista de atajos genéricos y se desconectó su callback en `KeyCallbacks`.

## Límites de esta pasada

Esto NO constituye una garantía de cero paquetes adicionales: siguen existiendo implementaciones de métodos `requestMetadata`, `requestQuery*`, `send*` y rutas de paquetes en otros archivos, aunque varias rutas de registro y ejecución ya quedaron desconectadas. También falta auditar dependencias de las consultas NBT y el guardado de esquemas, revisar configuraciones heredadas, compilar y probar con captura de tráfico. No se ejecutó Gradle.

## Próxima verificación

Auditoría de llamadas directas y eliminación segura de funciones de red residuales sin romper el uso de datos de bloques ya presentes en el cliente. Revisar el método `onEntityDataSyncToggled` y otras invocaciones directas de `EntityDataManager`.

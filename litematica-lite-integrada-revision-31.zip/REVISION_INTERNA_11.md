# Revisión interna 11 — configuración persistida

Se añadieron restablecimientos a `false` para `EASY_PLACE_MODE` y `PICK_BLOCK_ENABLED` inmediatamente después de leer la configuración en `Configs.loadFromFile()`. Esto evita que valores antiguos en el archivo JSON reactiven esas dos opciones al cargar.

**Limitaciones:** no se han cerrado todas las rutas ejecutables ni inspeccionado todos los menús. Falta comprobar si existen escrituras posteriores a esos valores, compilar y probar dentro de Minecraft. No distribuir.

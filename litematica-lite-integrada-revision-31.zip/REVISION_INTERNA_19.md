# Revisión interna 19 — Operaciones directas y Servux

## Correcciones aplicadas

- `EntityDataManager.sendServuxTaskRequest(...)`: método neutralizado. Evita solicitar tareas remotas mediante ese punto de entrada, independientemente del nombre de la tarea. La búsqueda estática no encontró llamadas desde otros archivos del proyecto.
- `LitematicaSchematic.sendTransmitFile(...)`: método experimental de transmisión de esquemas neutralizado. La búsqueda estática encontró únicamente una referencia comentada desde `SchematicPlacementManager`; suprimirlo reduce superficie de transmisión no requerida por el objetivo visual.

## Lo que se conserva

No se modificaron los paquetes de consulta de entidades ni los datos de bloques del servidor usados para visualización y verificación. No se alteró el código que construye el mundo esquemático en memoria.

## Límites de la revisión

La protección no es un filtro universal de paquetes. Quedan otras rutas de envío de datos que deben clasificarse, y no se ha compilado ni probado Minecraft. La búsqueda de referencias estáticas no prueba ausencia de reflexión o uso externo.

# Litematica Lite — prototipo 02 (código fuente, no compilado)

Objetivo: Minecraft 26.3.

## Cambios realizados
- Se quitaron los callbacks de activación y alternancia de Easy Place en `KeyCallbacks.java`.
- Se eliminó la rama que ejecutaba Easy Place mediante su tecla de activación.
- Se quitó la interceptación de uso de bloques por `PLACEMENT_RESTRICTION` en `InputHandler.java`.
- Se retiró el callback para alternar Placement Restriction.
- Se conservó el código de renderizado, capas, verificador y lista de materiales sin modificar en esta iteración.

## Estado y advertencias
- **No compilado ni probado en Minecraft.**
- **No es todavía un mod visual-only verificable**: quedan referencias a Easy Place, modos de edición y otras funciones que requieren auditoría.
- No usar en Dogcraft sin autorización explícita de sus administradores.
- Se conserva licencia original y atribuciones.

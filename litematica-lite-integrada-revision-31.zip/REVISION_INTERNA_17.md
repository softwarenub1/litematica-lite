# Revisión interna 17 — Mixins registrados y scheduler del servidor

Fecha: 2026-10-29. Alcance: inspección estática del árbol de trabajo `litematica-lite-revision-interna`. No se compiló ni se ejecutó Minecraft.

## Hallazgos comprobados

1. `src/main/resources/mixins.litematica.json` ya no registra `entity.MixinAbstractSignEditScreen`. Su clase permanece en el árbol, pero no aparece en las listas `mixins`, `client` ni `server`.
2. `mixin/server/MixinMinecraftServer.java` intercepta `MinecraftServer.logTickMethodTime` y llama a `TaskScheduler.getInstanceServer().runTasks()` cuando es servidor integrado y `shouldInformAdmins()` es verdadero. No coloca bloques directamente; sí permite ejecutar tareas que se hayan agendado en el scheduler del servidor.
3. `scheduler/TaskScheduler.java` rechaza tareas por prefijos del nombre simple (`TaskPaste`, `TaskDelete`, `TaskFill`, `TaskReplace`). Ese filtro no equivale a una política de permiso por tipo/operación: una tarea de edición con otro nombre podría pasar. El método `getServerInstanceIfExistsOrClient()` puede dirigir trabajo al scheduler del servidor en un mundo individual.
4. `mixin/network/MixinClientPacketListener.java` contiene manejadores para actualización/descarga de chunks (necesarios para renderizado), detección de Servux y respuesta a consultas NBT. No se debe eliminar el mixin completo sin analizar el impacto sobre renderizado y verificación.
5. `mixin/client/MixinOptions.java` actualiza la caché de modelos cuando se guardan opciones con Sodium; su propósito observado es visual.
6. `mixin/screen/MixinVideoSettingsScreen.java` refresca la caché de modelos al cerrar ajustes de video; su propósito observado es visual. `MixinAbstractContainerScreen.java` tiene sus inyecciones comentadas, y no figura en el JSON como mixin activo (solo aparece `IMixinAbstractContainerScreen`).

## Decisión

No borrar mixins por su nombre. Próximo cambio prioritario: clasificar todas las implementaciones de `ITask` y todos los lugares que las programan; sustituir el bloqueo por nombres por una política explícita y comprobar que tareas de análisis/guardado no pierdan funcionalidad. Auditar también las acciones de red hacia Servux.

## Estado

Inspección estática completada para estos componentes. Sin cambios de código en esta pasada, sin compilación y sin prueba de ejecución. No aprobado para distribución ni GitHub todavía.

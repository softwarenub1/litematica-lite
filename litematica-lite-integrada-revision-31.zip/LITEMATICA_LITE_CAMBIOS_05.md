# Litematica Lite — Prototipo 05 (experimental, no verificado)

- `ToolUtils`: operaciones de rellenar, borrar por selección y borrar por placement convertidas en métodos vacíos. Ya no generan solicitudes Servux ni tareas de edición.
- `TaskScheduler`: barrera adicional contra tareas cuyo nombre comienza con `TaskPaste`, `TaskDelete`, `TaskFill` o `TaskReplace`.
- Se preservan las tareas de análisis, verificación y guardado de esquemas.

**Advertencias:** Este bloqueo por nombre es una defensa parcial, no una garantía de solo lectura. No se ha compilado ni probado este prototipo. Deben auditarse otras vías de edición, paquetes de red, Mixins, interacción automática y UI. No instalar en Dogcraft sin autorización explícita.

# Revisión interna 28 — Dependencias visuales y tareas de análisis

## Cambio aplicado

- `render/OverlayRenderer.java`: eliminado el llamado explícito a `EntityDataManager.requestBlockEntityWrapped()` al señalar una discrepancia en el Schematic Verifier. Se conserva la comparación y el panel de información; eliminado también el import ahora innecesario.

## Comprobaciones estáticas

- `SchematicVerifier` se programa mediante `TaskScheduler.getInstanceClient()` y su clase está expresamente permitida por la lista de tareas.
- `MaterialListPlacement` usa `TaskCountBlocksPlacement` y `MaterialListAreaAnalyzer` usa `TaskCountBlocksArea`; ambas clases están permitidas.
- La ruta del panel de discrepancias sigue llamando a `RenderUtils.renderInventoryOverlays()`, que puede transitar por `InventoryUtils` y `EntityDataManager`. No se puede certificar aún que toda la visualización de inventarios sea estrictamente local; requiere revisión posterior.
- La ruta principal del renderizado de hologramas no se ha modificado en esta etapa.

## Pendiente

- Revisar `InventoryUtils.getTargetInventory()` y `EntityDataManager.requestBlockEntity()` para comprobar que ninguna ruta visual provoque paquetes adicionales.
- Revisar en detalle la interacción entre renderizado de esquemas, capas y los cambios de configuración.
- Compilar y ejecutar pruebas de verificador, materiales y holograma. No se ha compilado ni probado esta revisión.

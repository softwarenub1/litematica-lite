# Revisión interna 12 — puntos de entrada y HUD

Cambios aplicados en copia de trabajo, sin compilación:

1. `EntityUtils.shouldPickBlock(Player)` ahora devuelve `false` incondicionalmente. Así se bloquea el predicado compartido de selección automática incluso si una configuración cambia después de la carga. No demuestra por sí solo que no existan otras rutas directas de inventario.
2. `StatusInfoRenderer.getText()` deja de mostrar el indicador Easy Place; conserva la indicación de restricción de colocación, pendiente de decidir si debe mantenerse.

Pendientes: inspección de llamadas directas a `InventoryUtils`/`EasyPlaceUtils`, limpieza completa de GUI, restricciones, rutas Servux, compilación y pruebas en Minecraft.

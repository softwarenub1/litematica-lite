# Litematica Lite — Prototipo 04 (parcial, no compilado)

Objetivo fijo: Minecraft 26.3 / Fabric.

## Cambios realizados
- `KeyCallbacks.java`: deshabilitadas las ramas de teclas de selección asistida de bloques, ejecutar operación (pegar, rellenar, reemplazar, borrar) y borrado VCS.
- `InputHandler.java`: retirada la selección automática de bloques desde la tecla de uso.
- `GuiSchematicProjectManager.java`: la confirmación de pegar un proyecto ya no ejecuta el pegado.

## Lo que NO está terminado
- No se ha compilado ni probado el código.
- Permanecen otras rutas de edición, pegado, selección y posibles envíos de paquetes que deben auditarse antes de considerarlo de solo lectura.
- La verificación visual, las capas y Material List aún deben probarse en ejecución.
- Se requiere revisar la interfaz, los hotkeys, los Mixins y las funciones de proyectos.
- No utilizar en Dogcraft sin autorización explícita.

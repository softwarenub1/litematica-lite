# Revisión interna 10 — configuración y atajos

Cambios en copia de trabajo, **no aprobada para compilación o distribución**.

- Se retiraron 43 entradas de la lista visible `Configs.Generic.OPTIONS` (sin eliminar todavía los símbolos Java usados internamente).
- Se retiraron 7 entradas de `Hotkeys.HOTKEY_LIST`.
- Se desconectaron 4 callbacks de Pick Block y pegado de carteles.
- Se quitaron combinaciones predeterminadas de Easy Place y Pick Block, y se cambió el valor por defecto de Pick Block a `false`.

**Pendiente:** impedir carga de configuraciones antiguas que reactiven estas funciones; auditar callbacks restantes, pantallas especializadas, mixins, Servux y código de interacción; compilar y probar. Los cambios de listas no garantizan ausencia en todas las interfaces.

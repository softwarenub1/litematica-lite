# Revisión interna 25 — Cierre de solicitudes masivas y salida Servux

## Cambios aplicados
- `EntityDataManager.requestServuxBulkEntityData`: cuerpo neutralizado. Ya no construye ni envía solicitudes masivas de NBT.
- `ServuxLitematicaHandler.encodeClientData`: cuerpo neutralizado. Ya no permite ni siquiera los paquetes informativos anteriormente autorizados.

## Verificación estática
- Los métodos mencionados carecen ahora de llamadas de envío.
- `EntityDataManager.receiveServuxMetadata` aún invoca `encodeClientData` para desregistro, pero esa invocación termina en un método vacío. Debe limpiarse la dependencia restante.
- `TaskSaveSchematic` aún tiene una bifurcación para sincronización remota; se requiere adaptar explícitamente su lógica a lectura local para no dejar estados de espera.

## Pendiente
- Buscar otras rutas de red y registros; eliminar UI y referencias residuales.
- Revisar compilación y pruebas funcionales, incluida captura de tráfico en entorno controlado.
- No hay compilación ni prueba de juego en esta pasada.

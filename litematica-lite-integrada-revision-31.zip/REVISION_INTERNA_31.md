# Revisión interna 31 — Auditoría de integración (primera pasada)

## Cambio de código realizado

`src/main/java/fi/dy/masa/litematica/util/InventoryUtils.java`: eliminada la caché estática `lastBlockEntityContext` y su retorno de una vista de inventario anterior. Se retiró el import `Pair`. Las vistas del mundo cliente ahora solo devuelven el resultado de la lectura actual, sin reutilizar datos de una lectura previa.

## Rutas revisadas

- `TaskScheduler.scheduleTask`: lista de permisos exacta incluye `SchematicVerifier`, `TaskCountBlocksArea`, `TaskCountBlocksPlacement` y `TaskSaveSchematic`. Las tareas de pegado/comandos no están permitidas por esa ruta.
- `SchematicVerifier.startVerification`: programa el verificador en el scheduler cliente.
- `MaterialListPlacement` y `MaterialListAreaAnalyzer`: programan las dos tareas de recuento permitidas.
- `OverlayRenderer` y `RenderUtils`: siguen usando `InventoryUtils.getTargetInventory`; se elimina el riesgo de recuperar una vista anterior por la caché retirada.
- `TaskSaveSchematic`: `canProcessChunk` exige chunks disponibles; `onStop` solo escribe el esquema cuando `finished` es verdadero.
- Workflow `.github/workflows/build.yml`: configura Java 25 y `./gradlew build` en GitHub Actions.

## Riesgos y límites pendientes

1. **Sin compilación ni pruebas en juego**: la inspección estática no confirma compatibilidad de APIs ni comportamiento real del holograma, capas, materiales y verificador.
2. **Red**: encontrar rutas de envío neutralizadas o bloqueadas no demuestra ausencia total de paquetes. Falta revisión exhaustiva y prueba de tráfico.
3. **Guardado**: si un chunk se descarga durante la tarea, la comprobación previa no basta por sí sola para garantizar una captura atómica. Hay que probar ese caso.
4. **Mundo integrado**: algunas rutas de guardado todavía eligen el scheduler del servidor integrado; confirmar que el acceso a mundos y la tarea siguen siendo correctos en un jugador.
5. **Dependencia MaLiLib**: las rutas de mundo esquemático/servidor conservan utilidades de inventario de MaLiLib, que no se han auditado a nivel de fuente.

## Decisión

No se creó ZIP ni se afirmó que la versión compile. Próximo paso recomendado: revisión de compilabilidad y preparación de una única compilación integrada en GitHub Actions, seguida de pruebas funcionales y de red.

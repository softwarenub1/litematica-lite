# Prototipo 06 — Primer corte de auditoría (NO terminado)

- Bloqueado el punto de entrada `SchematicPlacementManager.pastePlacementToWorld(...)`, incluyendo la ruta directa de Servux.
- El ciclo de modos de herramienta solo alterna entre selección de área y colocación visual de esquemas.
- **Pendiente:** ocultar opciones y atajos de la interfaz, bloquear Easy Place y pick block en puntos de entrada, revisar otras rutas de modificación y hacer pruebas funcionales.
- **No instalar en servidores.** No está compilado ni auditado.

# Revisión interna 21 — Comandos salientes y rutas de escritura

## Cambio aplicado

En `TaskProcessChunkMultiPhase.java`, el método `sendCommand(String, LocalPlayer)` ya no llama a `player.connection.sendCommand(command)`. Se conserva el incremento del contador para evitar un bucle en tareas heredadas que accidentalmente lleguen a ejecutarse. El bloqueo es una defensa adicional: el planificador ya usa una lista de tareas permitidas.

## Hallazgos estáticos

- Se encontraron llamadas a `sendCommand` en tareas antiguas de pegado, relleno y borrado; ahora el método base no envía comandos.
- `TaskPasteSchematicSetblockToMcfunction` **sobrescribe** el método para escribir comandos en archivos `.mcfunction`; no envía paquetes, pero sigue siendo una funcionalidad no deseada que habrá que retirar de la interfaz y bloquear desde sus constructores o puntos de entrada.
- `TaskFillArea` y `TaskDeleteBlocksByPlacement` contienen `world.setBlock`; estas rutas no quedan neutralizadas por la protección de comandos. Deben verificarse los puntos de entrada y el tipo de mundo.
- `WorldPlacingUtils`, `SchematicPlacingUtils` y clases de esquemas escriben bloques en representaciones de mundos; no se deben eliminar sin verificar si trabajan sobre el mundo esquemático en memoria.

## Verificación

Se comprobó estáticamente que el método base ya no contiene `connection.sendCommand`. No se compiló ni se probó en Minecraft. No está listo para GitHub.

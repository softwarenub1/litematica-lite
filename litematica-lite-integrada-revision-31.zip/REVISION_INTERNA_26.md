# Revisión interna 26 — Guardado de esquemas exclusivamente local

## Cambio aplicado

Archivo: `src/main/java/fi/dy/masa/litematica/scheduler/tasks/TaskSaveSchematic.java`

- Eliminada la rama de `canProcessChunk()` que solicitaba datos NBT masivos a Servux o al sistema de paquetes de respaldo, y que podía esperar indefinidamente una respuesta.
- Ahora se procesa el chunk solo cuando está disponible en el mundo cliente; no se inicia ninguna solicitud remota desde esta tarea.
- `processChunk()` utiliza `clientWorld` (o `schematicWorld` cuando corresponde), en lugar del mundo elegido por `WorldUtils.getBestWorld()` que podía apuntar al servidor integrado.
- Eliminada la lógica que marcaba como consumidos los datos remotos de chunks.
- Limpiadas importaciones sin uso.

## Alcance y limitaciones

Es una corrección estática específica del guardado; no certifica que todas las rutas de red del mod estén eliminadas. El esquema guardado solo puede incluir datos disponibles en el cliente; los datos NBT de bloques o entidades que el servidor no haya sincronizado pueden faltar. No se ha compilado ni probado en Minecraft.

## Próxima comprobación

Auditar `EntityDataManager`, las rutas de captura de NBT y el comportamiento del guardado ante chunks sin cargar, y después verificar compilación y pruebas funcionales.

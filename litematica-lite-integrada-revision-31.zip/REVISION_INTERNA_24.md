# Revisión interna 24 — Consultas remotas

## Cambios aplicados
En `src/main/java/fi/dy/masa/litematica/data/EntityDataManager.java` se neutralizaron los cuerpos de seis métodos, conservando firmas para compatibilidad de llamadas:
- `requestMetadata`
- `requestQueryBlockEntity`
- `requestQueryEntityData`
- `requestServuxBlockEntityData`
- `requestServuxEntityData`
- `onEntityDataSyncToggled`

## Comprobación estática
Ya no quedan invocaciones `queryBlockEntityTag` ni `queryEntityTag` dentro de ese archivo. Aún quedan referencias `HANDLER.encodeClientData` en `receiveServuxMetadata` y `requestServuxBulkEntityData`, por lo que NO se considera cerrada la auditoría de red.

## Pendiente
Revisar rutas de consultas masivas, guardado local, envío de paquetes y registros de red. Compilar y probar. Esta pasada no ejecutó Gradle ni pruebas en Minecraft.

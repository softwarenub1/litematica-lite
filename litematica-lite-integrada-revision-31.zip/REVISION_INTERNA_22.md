# Revisión interna 22 — Escritura directa y exportación de comandos

## Cambios aplicados

- `TaskFillArea.canExecute()` devuelve `false` para impedir el procesamiento de relleno, incluido su método de escritura directa en un mundo.
- `TaskDeleteBlocksByPlacement.canExecute()` devuelve `false` para impedir el borrado directo.
- `TaskPasteSchematicPerChunkDirect.canExecute()` devuelve `false` para impedir el pegado directo en el servidor integrado.
- `TaskPasteSchematicSetblockToMcfunction.canExecute()` devuelve `false`, y su constructor deja de crear un archivo `.mcfunction` al instanciarse.

## Alcance y límites

Estos son bloqueos de ejecución adicionales, no una eliminación completa de las implementaciones. No se ha comprobado todavía que todos los puntos de entrada estén retirados de la interfaz ni que no existan llamadas directas a métodos auxiliares. No se ha compilado ni probado el mod.

Se conservan `WorldSchematic`, `ChunkSchematic`, `PlacementManagerTaskRebuild` y sus operaciones de escritura en memoria, necesarias para construir el mundo esquemático y renderizar hologramas.

## Próxima validación

Auditar llamadas directas a métodos de edición fuera de las tareas y verificar referencias residuales en pantallas y configuraciones. Posteriormente, compilar y probar.

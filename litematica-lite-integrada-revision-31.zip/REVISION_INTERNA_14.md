# Revisión interna 14 — Selección automática e inventario

**Estado:** cambios locales aplicados; no compilados ni probados.

En `src/main/java/fi/dy/masa/litematica/util/InventoryUtils.java` se neutralizaron:

- `preRestockHand(...)`: antes enviaba acciones `handleContainerInput` para reponer automáticamente el objeto de la mano.
- `getPickedItemHandSlotNoSwap(int, ItemStack, Minecraft)`: pese a su nombre «NoSwap», cambiaba el slot seleccionado con `setSelectedSlot`; ahora devuelve `-1` sin efectos.
- `schematicWorldPickBlock(...)`: selección automática de objetos a partir del mundo esquemático; ahora no ejecuta acciones.

Se conservan firmas y métodos de consulta de inventario que pueden alimentar superposiciones informativas. La sobrecarga de `getPickedItemHandSlotNoSwap(ItemStack, Minecraft)` ahora llega a la variante neutralizada.

**Riesgos pendientes:** `getMainHandSlotForItem` conserva una modificación de slot aunque actualmente solo se identificó como auxiliar del método neutralizado; revisar llamadas indirectas, menús, rutas de eventos y dependencias. No se ha ejecutado Gradle ni prueba en juego.

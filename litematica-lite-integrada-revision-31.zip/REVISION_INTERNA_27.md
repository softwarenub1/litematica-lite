# Revisión interna 27 — Guardado con chunks descargados y consultas de respaldo

## Cambios realizados

1. `TaskSaveSchematic.execute()` ahora comprueba **todos** los chunks de la selección antes de copiar cualquier bloque. Si falta uno, muestra un error con las coordenadas del primer chunk y termina la tarea sin escribir el archivo. Esto evita una espera indefinida y la generación de un esquema incompleto.
2. `EntityDataManager.requestBackupBulkEntityData()` queda neutralizado. Era una ruta de respaldo que recorría entidades y bloques para solicitar NBT; ya no tiene sentido en el diseño exclusivamente local.

## Límites y verificaciones pendientes

- La comprobación se hace al empezar la ejecución; si los chunks se descargan durante el procesamiento, aún debemos estudiar un control adicional para abortar limpiamente antes de guardar.
- No se ha compilado ni probado en Minecraft. Se requiere verificar firmas de API y mensajes en el cliente.
- Continúa pendiente una auditoría integral de rutas de red, tareas y funciones de guardado.

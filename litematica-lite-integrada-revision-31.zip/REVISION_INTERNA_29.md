# Revisión interna 29 — Inventarios visuales sin consultas NBT remotas

## Modificación aplicada

Archivo: `src/main/java/fi/dy/masa/litematica/util/InventoryUtils.java`.

- `getTargetInventory`: para mundos del cliente reemplazado `EntityDataManager.requestBlockEntityWrapped()` por `world.getBlockEntity(pos)` y serialización únicamente de datos ya presentes localmente. Se conserva el comportamiento especial del mundo esquemático.
- `getTargetInventoryFromBlock`: eliminado el segundo camino de consulta `requestBlockEntityWrapped`; usa la entidad de bloque local cuando existe.
- `getTargetInventoryFromBlock` y `getCombinedInventory`: sustituidas las consultas de inventario a través de `EntityDataManager.getBlockInventoryWrapped()` por la utilidad local de inventarios de MaLiLib.

## Resultado de inspección estática

`InventoryUtils.java` ya no contiene llamadas a `requestBlockEntityWrapped` ni `getBlockInventoryWrapped`. Las vistas de inventario podrían mostrar menos información en multijugador, lo cual coincide con la prioridad del proyecto de no recuperar contenidos remotos de cofres.

## Precauciones pendientes

- **No se ha compilado ni ejecutado** esta modificación. Es necesario validar la API de Minecraft 26.3, la disponibilidad de `saveWithFullMetadata` en entidades de bloque del cliente y el funcionamiento de las superposiciones.
- La utilidad `fi.dy.masa.malilib.util.InventoryUtils.getInventory` pertenece a una dependencia externa y todavía debe auditarse para verificar que no envíe paquetes ni invoque rutas de solicitud NBT. No se certifica silencio de red completo.
- La inspección estática no demuestra que todas las rutas de renderizado, capas y verificación funcionen. Deben probarse en cliente y observarse los paquetes de salida.

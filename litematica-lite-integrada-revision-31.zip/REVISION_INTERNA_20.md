# Revisión interna 20 — Lista permitida de paquetes Servux salientes

## Cambio aplicado

En `src/main/java/fi/dy/masa/litematica/network/ServuxLitematicaHandler.java` se incorporó una lista explícita de tipos permitidos en `encodeClientData`: solicitud de metadatos, consulta de NBT de bloque/entidad, consulta NBT por lotes y aviso de desregistro. Los demás tipos salen inmediatamente sin enviarse, incluyendo solicitud/cancelación de tareas y transmisión de datos NBT desde el cliente.

`encodeWithSplitter` ya no transmite fragmentos salientes de datos. Se eliminó la rama de envío de respuestas NBT por PacketSplitter que quedó inaccesible tras el filtro.

## Comprobaciones estáticas

- Los cinco tipos permitidos son `PACKET_C2S_METADATA_REQUEST`, `PACKET_C2S_BLOCK_ENTITY_REQUEST`, `PACKET_C2S_ENTITY_REQUEST`, `PACKET_C2S_BULK_ENTITY_NBT_REQUEST` y `PACKET_C2S_UNREGISTER_REPLY`.
- El filtro está antes del único `sendPlayPayload` de `encodeClientData`.
- El método `encodeWithSplitter` no llama a `sendPlayPayload`.

## Limitaciones

No se ha compilado ni ejecutado el mod. Esto solo restringe el envío a través de este manejador: no demuestra que otros canales, clases o APIs de red carezcan de rutas de modificación. Hay que revisar compatibilidad de las consultas NBT con Dogcraft y preservar solo las que sean necesarias.

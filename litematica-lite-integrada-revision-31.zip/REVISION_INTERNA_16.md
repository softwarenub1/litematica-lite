# Revisión interna 16 — barrido global de interfaz y mixins

Se recorrieron todas las clases Java de `gui/` buscando `paste`, `delete`, `fill`, `replace`, `easyplace`, `pickblock` y `execute` (sin distinguir mayúsculas). Solo hubo coincidencias en `GuiSchematicManager`, `GuiSchematicProjectsBrowser`, `GuiMaterialListSave` y `GuiSchematicSave`.

- `GuiSchematicManager`: `DELETE_FILE` elimina archivos locales de esquemas, no bloques del mundo. **Conservar**.
- `GuiSchematicProjectsBrowser`: `DELETE_PROJECT` elimina archivos locales de proyectos, no bloques del mundo. **Conservar**.
- `GuiMaterialListSave` y `GuiSchematicSave`: coincidencias `replace`/`execute` requieren clasificación contextual; no deben eliminarse por palabra clave.
- Hallazgo adicional fuera de `gui/`: `MixinAbstractSignEditScreen` inyectaba texto del esquema al abrir el editor de carteles cuando `SIGN_TEXT_PASTE` estaba habilitado. Eso es asistencia de edición y no corresponde al alcance visual.

## Cambios aplicados

1. Eliminado `entity.MixinAbstractSignEditScreen` de la lista `client` de `mixins.litematica.json`, evitando la inyección. JSON validado.
2. Cambiado valor predeterminado `SIGN_TEXT_PASTE` de `true` a `false` en `Configs.java`.

## Limitaciones y pendientes

No se compiló ni ejecutó Minecraft. La clase del mixin y la configuración siguen definidas en el código, aunque el mixin no se registra; deberán limpiarse al finalizar la revisión de dependencias. Revisar otras inyecciones y pantallas fuera del paquete `gui`, y validar la compilación y pruebas visuales antes de distribuir.

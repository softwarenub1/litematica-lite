# Litematica Lite — prototipo 03 (fuente, sin compilar)

Minecraft objetivo: **26.3**.

## Cambio efectivo de esta iteración
- Se eliminó la ejecución periódica de Easy Place desde `ClientTickHandler.onClientTick`, incluyendo ambas rutas (`EasyPlaceUtils.easyPlaceOnUseTick` y `WorldUtils.easyPlaceOnUseTick`).
- Se conservaron las llamadas de actualización de capas, placements y tareas, para no alterar deliberadamente la visualización.

## Riesgos pendientes
- **No es todavía un mod de solo visualización**: persisten `EasyPlaceUtils`, `PlacementHandler`, protocolos de colocación y referencias en otras clases.
- Deben auditarse además pick-block, edición, pegado de schematics, comandos y cualquier ruta que envíe acciones al servidor.
- Hay que verificar Schematic Verifier (incluida orientación) y Material List con pruebas reales.
- **No compilado**: el entorno actual tiene Java 21 y el proyecto requiere un toolchain más reciente; no se ha confirmado resolución de dependencias.
- No instalar en Dogcraft sin permiso explícito.

## Siguiente intervención
Mapear invocaciones a `EasyPlaceUtils`, `PlacementHandler` y `WorldUtils` y quitar o aislar las rutas activas antes de intentar una compilación.

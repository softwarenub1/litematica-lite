# Revisión interna 30 — Aislamiento de inventarios del cliente

## Cambio aplicado

Archivo: `src/main/java/fi/dy/masa/litematica/util/InventoryUtils.java`.

Se añadió `getLocallyAvailableInventory(Level, BlockPos)` y se sustituyeron las tres llamadas directas a `fi.dy.masa.malilib.util.InventoryUtils.getInventory(world, pos)` que se hacían desde las vistas de inventario.

- En el mundo cliente normal, el método consulta únicamente `world.getBlockEntity(pos)` y devuelve el objeto si implementa `Container`.
- En mundos esquemáticos (`WorldSchematic`) o `ServerLevel`, conserva la utilidad de MaLiLib para no alterar la lectura de esquemas.
- `getTargetInventoryFromBlock` y `getCombinedInventory` usan ahora esta ruta controlada.

## Efecto y límites

Esta modificación **evita invocar la utilidad externa de MaLiLib en la ruta de lectura de inventarios del mundo cliente**; no equivale a haber auditado el código de MaLiLib, que no está disponible aquí como fuente. Algunos contenedores compuestos, como cofres dobles, pueden perder precisión en la superposición visual; sus bloques y orientaciones no dependen de esta superposición.

**Pendiente:** revisar `lastBlockEntityContext` para evitar vistas de inventario obsoletas; comprobar APIs, compilación, comportamiento de capas, verificador y material list; hacer pruebas de red para descartar tráfico adicional en el mod completo. Java local es 21, mientras que el proyecto requiere Java 25; no se ha compilado ni probado en Minecraft.

## Decisión

No se preparó ni subió ZIP a GitHub. Siguiente paso: auditoría de integración y compilación con Java 25 mediante GitHub Actions cuando el código esté listo.

# Revisión interna 13 — Neutralización de puntos de entrada

Fecha: 2026-10-29. Trabajo local, **sin compilación ni pruebas en juego**.

Se reemplazaron los cuerpos de once métodos en cuatro archivos:

- `EasyPlaceUtils`: `shouldDoEasyPlaceActions` -> false, `easyPlaceOnUseTick` -> no-op, `handleEasyPlaceWithMessage` -> false, `onRightClickTail` -> no-op, `handleEasyPlace` -> PASS.
- `WorldUtils`: `easyPlaceOnUseTick` -> no-op, `handleEasyPlace` -> false, `doEasyPlaceAction` -> PASS.
- `InventoryUtils`: `setPickedItemToHand(int, ItemStack, Minecraft)` -> no-op; la sobrecarga que llama a este método queda indirectamente neutralizada.
- `PickBlockUtils`: `doPickBlockForStack` y `pickBlockLast` -> null.

Las firmas se preservaron para evitar romper referencias. La modificación se hizo mediante un reemplazo delimitado por llaves. **No se ha demostrado que cubra todos los caminos de interacción ni que compile.**

Siguiente trabajo: revisar `preRestockHand`, otros movimientos de inventario, `placementRestriction`, pantallas y listas de opciones; comprobar cambios con un compilador y ejecutar pruebas en un cliente de prueba fuera del servidor.

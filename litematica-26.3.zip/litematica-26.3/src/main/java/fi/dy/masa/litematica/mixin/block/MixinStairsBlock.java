package fi.dy.masa.litematica.mixin.block;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fi.dy.masa.litematica.config.Configs;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.StairsShape;

import static net.minecraft.world.level.block.StairBlock.FACING;
import static net.minecraft.world.level.block.StairBlock.SHAPE;

@Mixin(StairBlock.class)
public abstract class MixinStairsBlock extends Block
{
    public MixinStairsBlock(Properties settings)
    {
        super(settings);
    }

    @Inject(method = "mirror", at = @At(value = "HEAD"), cancellable = true)
    private void litematica_fixStairsMirror(BlockState state, Mirror mirror, CallbackInfoReturnable<BlockState> cir)
    {
        if (Configs.Generic.FIX_STAIRS_MIRROR.getBooleanValue())
        {
            Direction direction = state.getValue(FACING);
            StairsShape stairShape = state.getValue(SHAPE);

            // Fixes X Axis for FRONT_BACK being inverted for INNER_LEFT / INNER_RIGHT
            if (direction.getAxis() == Direction.Axis.X && mirror == Mirror.FRONT_BACK)
            {
                cir.setReturnValue(
                        switch (stairShape)
                        {
                            case INNER_LEFT  -> state.rotate(Rotation.CLOCKWISE_180).setValue(SHAPE, StairsShape.INNER_RIGHT);
                            case INNER_RIGHT -> state.rotate(Rotation.CLOCKWISE_180).setValue(SHAPE, StairsShape.INNER_LEFT);
                            case OUTER_LEFT  -> state.rotate(Rotation.CLOCKWISE_180).setValue(SHAPE, StairsShape.OUTER_RIGHT);
                            case OUTER_RIGHT -> state.rotate(Rotation.CLOCKWISE_180).setValue(SHAPE, StairsShape.OUTER_LEFT);
                            default          -> state.rotate(Rotation.CLOCKWISE_180);
                        }
                );

                cir.cancel();
            }
            // Fixes missing Axis STAIR_SHAPE flips
            else if ((direction.getAxis() == Direction.Axis.X && mirror == Mirror.LEFT_RIGHT) ||
                     (direction.getAxis() == Direction.Axis.Z && mirror == Mirror.FRONT_BACK))
            {
                cir.setReturnValue(
                        switch (stairShape)
                        {
                            case INNER_LEFT  -> state.setValue(SHAPE, StairsShape.INNER_RIGHT);
                            case INNER_RIGHT -> state.setValue(SHAPE, StairsShape.INNER_LEFT);
                            case OUTER_LEFT  -> state.setValue(SHAPE, StairsShape.OUTER_RIGHT);
                            case OUTER_RIGHT -> state.setValue(SHAPE, StairsShape.OUTER_LEFT);
                            default          -> state;
                        }
                );

                cir.cancel();
            }
        }
    }
}

package fi.dy.masa.litematica.materials;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.Vec3i;
import net.minecraft.world.Container;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import fi.dy.masa.malilib.registry.Registry;
import fi.dy.masa.malilib.util.InventoryUtils;
import fi.dy.masa.malilib.util.data.DataEntityUtils;
import fi.dy.masa.malilib.util.data.ItemType;
import fi.dy.masa.malilib.util.data.tag.CompoundData;
import fi.dy.masa.malilib.util.nbt.NbtInventory;
import fi.dy.masa.malilib.util.nbt.NbtView;
import fi.dy.masa.litematica.Litematica;
import fi.dy.masa.litematica.config.Configs;
import fi.dy.masa.litematica.schematic.LitematicaSchematic;
import fi.dy.masa.litematica.schematic.container.LitematicaBlockStateContainer;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.litematica.world.WorldSchematic;

public class MaterialListUtils
{
    public static List<MaterialListEntry> createMaterialListFor(LitematicaSchematic schematic)
    {
        return createMaterialListFor(schematic, schematic.getAreas().keySet());
    }

    /**
     * Creates a material list directly from item types and quantities,
     * bypassing the block-based conversion system. This allows tracking
     * of any item type including non-placeable items like tools and food.
     *
     * @param items Map of ItemType to quantity
     * @param player Player entity for inventory tracking (can be null)
     * @return List of MaterialListEntry objects
     */
    public static List<MaterialListEntry> createMaterialListFromItems(
		    java.util.Map<ItemType, Integer> items, Player player)
    {
        List<MaterialListEntry> list = new ArrayList<>();

        if (items.isEmpty())
        {
            return list;
        }

        Object2IntOpenHashMap<ItemType> playerInvItems = null;
        Object2IntOpenHashMap<ItemType> enderItems = null;

        if (player != null)
        {
            playerInvItems = getInventoryItemCounts(player.getInventory());
            NbtInventory ender = Registry.ENTITY_DATA_REGISTRY.chestTracker().getEnderCache();

            if (Configs.Generic.MATERIAL_LIST_COUNT_ENDER_CACHE.getBooleanValue() && ender != null)
            {
                Container ec = ender.toInventory(NbtInventory.DEFAULT_SIZE);

                if (ec != null)
                {
                    enderItems = getInventoryItemCounts(ec);
                }
            }
        }

        for (java.util.Map.Entry<ItemType, Integer> entry : items.entrySet())
        {
            ItemType type = entry.getKey();
            int count = entry.getValue();
            int countAvailable = playerInvItems != null
                                 ? playerInvItems.getInt(type)
                                 : 0;

            countAvailable += enderItems != null ? enderItems.getInt(type) : 0;

            // For custom item lists, total = missing (no placement state to compare against)
            list.add(new MaterialListEntry(
                type.getStack().copy(),
                count,           // countTotal
                count,           // countMissing (all items are "missing" since nothing is placed)
                0,               // countMismatched (not applicable for custom lists)
                countAvailable   // countAvailable (from player inventory)
            ));
        }

        return list;
    }

    public static List<MaterialListEntry> createMaterialListFor(LitematicaSchematic schematic, Collection<String> subRegions)
    {
        Object2IntOpenHashMap<BlockState> countsTotal = new Object2IntOpenHashMap<>();
        Object2IntOpenHashMap<MaterialListEntityInfo> entitiesTotal = new Object2IntOpenHashMap<>();

        for (String regionName : subRegions)
        {
            LitematicaBlockStateContainer container = schematic.getSubRegionContainer(regionName);
            List<LitematicaSchematic.EntityInfo> entities = schematic.getEntityListForRegion(regionName);

            if (container != null)
            {
                Vec3i size = container.getSize();
                final int sizeX = size.getX();
                final int sizeY = size.getY();
                final int sizeZ = size.getZ();

                for (int y = 0; y < sizeY; ++y)
                {
                    for (int z = 0; z < sizeZ; ++z)
                    {
                        for (int x = 0; x < sizeX; ++x)
                        {
                            BlockState state = container.get(x, y, z);
                            countsTotal.addTo(state, 1);
                        }
                    }
                }
            }

            if (entities != null && !entities.isEmpty())
            {
                for (LitematicaSchematic.EntityInfo info : entities)
                {
                    CompoundData data = info.nbt();
                    WorldSchematic world = SchematicWorldHandler.INSTANCE.getWorld();
                    RegistryAccess registry = SchematicWorldHandler.INSTANCE.getRegistryManager();
                    ItemStack pickStack = null;
                    Entity entity = null;

                    if (registry != null && world != null)
                    {
                        NbtView view = NbtView.getReader(data, registry);
                        Optional<Entity> opt = EntityType.create(view.getReader(), world, new EntitySpawnRequest(EntitySpawnReason.LOAD, true));

                        if (opt.isPresent())
                        {
                            entity = opt.get();
                            pickStack = entity.getPickResult();

                            // Ignore entities without a Pick Stack (i.e. Only read Cushions, Item Frames, Paintings, etc.)
                            if (pickStack != null && !pickStack.isEmpty())
                            {
                                entitiesTotal.addTo(new MaterialListEntityInfo(info.posVec(), data, pickStack.copy()), 1);
                            }
                        }
                    }
                }
            }
        }

        Minecraft mc = Minecraft.getInstance();

        Litematica.debugLog("createMaterialListFor():Schematic: totalBlocks: {}, totalEntities: {}", countsTotal.size(), entitiesTotal.size());

        return getMaterialList(countsTotal, countsTotal.clone(), new Object2IntOpenHashMap<>(),
                               entitiesTotal, entitiesTotal.clone(), new Object2IntOpenHashMap<>(),
                               mc.player);
    }

    public static List<MaterialListEntry> getMaterialList(
            Object2IntOpenHashMap<BlockState> countsTotal,
            Object2IntOpenHashMap<BlockState> countsMissing,
            Object2IntOpenHashMap<BlockState> countsMismatch,
            Object2IntOpenHashMap<MaterialListEntityInfo> entitiesTotal,
            Object2IntOpenHashMap<MaterialListEntityInfo> entitiesMissing,
            Object2IntOpenHashMap<MaterialListEntityInfo> entitiesMismatch,
            Player player)
    {
        List<MaterialListEntry> list = new ArrayList<>();

        if (!countsTotal.isEmpty())
        {
            MaterialCache cache = MaterialCache.getInstance();
            Object2IntOpenHashMap<ItemType> itemTypesTotal = new Object2IntOpenHashMap<>();
            Object2IntOpenHashMap<ItemType> itemTypesMissing = new Object2IntOpenHashMap<>();
            Object2IntOpenHashMap<ItemType> itemTypesMismatch = new Object2IntOpenHashMap<>();

            convertStatesToStacks(countsTotal, itemTypesTotal, cache);
            convertStatesToStacks(countsMissing, itemTypesMissing, cache);
            convertStatesToStacks(countsMismatch, itemTypesMismatch, cache);

            convertEntitiesToStacks(entitiesTotal, itemTypesTotal, cache);
            convertEntitiesToStacks(entitiesMissing, itemTypesMissing, cache);
            convertEntitiesToStacks(entitiesMismatch, itemTypesMismatch, cache);

            if (player != null)
            {
                Object2IntOpenHashMap<ItemType> playerInvItems = getInventoryItemCounts(player.getInventory());
                Object2IntOpenHashMap<ItemType> enderItems = null;
                NbtInventory ender = Registry.ENTITY_DATA_REGISTRY.chestTracker().getEnderCache();

                if (Configs.Generic.MATERIAL_LIST_COUNT_ENDER_CACHE.getBooleanValue() && ender != null)
                {
                    Container ec = ender.toInventory(NbtInventory.DEFAULT_SIZE);

                    if (ec != null)
                    {
                        enderItems = getInventoryItemCounts(ec);
                    }
                }

                for (ItemType type : itemTypesTotal.keySet())
                {
                    final int enderCount = enderItems != null ? enderItems.getInt(type) : 0;

                    list.add(new MaterialListEntry(type.getStack().copy(),
                                                   itemTypesTotal.getInt(type),
                                                   itemTypesMissing.getInt(type),
                                                   itemTypesMismatch.getInt(type),
                                                   playerInvItems.getInt(type) + enderCount
                    ));
                }
            }
            else
            {
                for (ItemType type : itemTypesTotal.keySet())
                {
                    list.add(new MaterialListEntry(type.getStack().copy(),
                                                   itemTypesTotal.getInt(type),
                                                   itemTypesMissing.getInt(type),
                                                   itemTypesMismatch.getInt(type),
                                                   0));
                }
            }
        }

        return list;
    }

    private static void convertEntitiesToStacks(
            Object2IntOpenHashMap<MaterialListEntityInfo> entitiesIn,
            Object2IntOpenHashMap<ItemType> itemTypesOut,
            MaterialCache cache)
    {
        for (MaterialListEntityInfo entry : entitiesIn.keySet())
        {
            int count = entitiesIn.getInt(entry);
            ItemStack pickStack = cache.getRequiredBuildItemForEntity(entry);

            if (pickStack != null && !pickStack.isEmpty())
            {
                EntityType<?> type = DataEntityUtils.getEntityType(entry.data());

                addEntityTypeOverrides(type, itemTypesOut, pickStack, count);

                itemTypesOut.addTo(new ItemType(pickStack, true, false), count * pickStack.getCount());
            }
        }
    }

    private static void addEntityTypeOverrides(EntityType<?> type, Object2IntOpenHashMap<ItemType> itemTypesOut, ItemStack pickStack, int count)
    {
        if (type != null)
        {
            if (type.equals(EntityTypes.ITEM_FRAME) && pickStack != null && !pickStack.is(Items.ITEM_FRAME))
            {
                itemTypesOut.addTo(new ItemType(new ItemStack(Items.ITEM_FRAME), true, false), count);
            }
            else if (type.equals(EntityTypes.GLOW_ITEM_FRAME) && pickStack != null && !pickStack.is(Items.GLOW_ITEM_FRAME))
            {
                itemTypesOut.addTo(new ItemType(new ItemStack(Items.GLOW_ITEM_FRAME), true, false), count);
            }
        }
    }

    private static void convertStatesToStacks(
            Object2IntOpenHashMap<BlockState> blockStatesIn,
            Object2IntOpenHashMap<ItemType> itemTypesOut,
            MaterialCache cache)
    {
        for (BlockState state : blockStatesIn.keySet())
        {
            int count = blockStatesIn.getInt(state);
            BlockState stateToConvert = isWaterloggedBlock(state) ? getBaseBlockState(state) : state;

            // Add water bucket for waterlogged blocks
            if (isWaterloggedBlock(state))
            {
                itemTypesOut.addTo(new ItemType(new ItemStack(Items.WATER_BUCKET), false, false), count);
            }

            // Convert block to items
            if (cache.requiresMultipleItems(stateToConvert))
            {
                for (ItemStack stack : cache.getItems(stateToConvert))
                {
                    if (!stack.isEmpty())
                    {
                        itemTypesOut.addTo(new ItemType(stack, true, false), count * stack.getCount());
                    }
                }
            }
            else
            {
                ItemStack stack = cache.getRequiredBuildItemForState(stateToConvert);
                if (!stack.isEmpty())
                {
                    itemTypesOut.addTo(new ItemType(stack, true, false), count * stack.getCount());
                }
            }
        }
    }

    public static void updateAvailableCounts(List<MaterialListEntry> list, Player player)
    {
        if (player == null) return;
        Object2IntOpenHashMap<ItemType> playerInvItems = getInventoryItemCounts(player.getInventory());
        Object2IntOpenHashMap<ItemType> enderItems = null;
        NbtInventory ender = Registry.ENTITY_DATA_REGISTRY.chestTracker().getEnderCache();

        if (Configs.Generic.MATERIAL_LIST_COUNT_ENDER_CACHE.getBooleanValue() && ender != null)
        {
            Container ec = ender.toInventory(NbtInventory.DEFAULT_SIZE);

            if (ec != null)
            {
                enderItems = getInventoryItemCounts(ec);
            }
        }

        for (MaterialListEntry entry : list)
        {
            ItemType type = new ItemType(entry.getStack(), true, false);
            int countAvailable = enderItems != null
                                 ? playerInvItems.getInt(type) + enderItems.getInt(type)
                                 : playerInvItems.getInt(type);
            entry.setCountAvailable(countAvailable);
        }
    }

    public static Object2IntOpenHashMap<ItemType> getInventoryItemCounts(Container inv)
    {
        Object2IntOpenHashMap<ItemType> map = new Object2IntOpenHashMap<>();
        final int slots = inv.getContainerSize();

        for (int slot = 0; slot < slots; ++slot)
        {
            ItemStack stack = inv.getItem(slot);

            if (stack.isEmpty() == false)
            {
                Item item = stack.getItem();

                if (item instanceof BlockItem &&
                    ((BlockItem) stack.getItem()).getBlock() instanceof ShulkerBoxBlock &&
                    InventoryUtils.shulkerBoxHasItems(stack))
                {
                    Object2IntOpenHashMap<ItemType> boxCounts = getStoredItemCounts(stack);

                    for (ItemType boxType : boxCounts.keySet())
                    {
                        map.addTo(boxType, boxCounts.getInt(boxType));
                    }

                    boxCounts.clear();
                }
                else if (item instanceof BundleItem && InventoryUtils.bundleHasItems(stack))
                {
                    Object2IntOpenHashMap<ItemType> bundleCounts = getBundleItemCounts(stack);

                    for (ItemType bundleType : bundleCounts.keySet())
                    {
                        map.addTo(bundleType, bundleCounts.getInt(bundleType));
                    }

                    bundleCounts.clear();
                }
                else
                {
                    map.addTo(new ItemType(stack, true, false), stack.getCount());
                }
            }
        }

        return map;
    }

    public static Object2IntOpenHashMap<ItemType> getStoredItemCounts(ItemStack stackShulkerBox)
    {
        Object2IntOpenHashMap<ItemType> map = new Object2IntOpenHashMap<>();
        NonNullList<ItemStack> items = InventoryUtils.getStoredItems(stackShulkerBox);
		int multiplier = stackShulkerBox.getCount();

        for (ItemStack boxStack : items)
        {
            if (boxStack.isEmpty() == false)
            {
                // Copy Nested Bundles
                if (boxStack.getItem() instanceof BundleItem && InventoryUtils.bundleHasItems(boxStack))
                {
                    Object2IntOpenHashMap<ItemType> bundleMap = getBundleItemCounts(boxStack);

                    if (!bundleMap.isEmpty())
                    {
                        bundleMap.forEach(map::addTo);
                    }
                }
				
                map.addTo(new ItemType(boxStack, false, false), boxStack.getCount() * multiplier);
            }
        }

        return map;
    }

    public static Object2IntOpenHashMap<ItemType> getBundleItemCounts(ItemStack stackBundle)
    {
        Object2IntOpenHashMap<ItemType> map = new Object2IntOpenHashMap<>();
        NonNullList<ItemStack> items = InventoryUtils.getBundleItems(stackBundle);

        for (ItemStack bundleStack : items)
        {
            if (bundleStack.isEmpty() == false)
            {
                // Copy Nested Bundles
                if (bundleStack.getItem() instanceof BundleItem && InventoryUtils.bundleHasItems(bundleStack))
                {
                    Object2IntOpenHashMap<ItemType> bundleMap = getBundleItemCounts(bundleStack);

                    if (!bundleMap.isEmpty())
                    {
                        bundleMap.forEach(map::addTo);
                    }
                }

                map.addTo(new ItemType(bundleStack, false, false), bundleStack.getCount());
            }
        }

        return map;
    }

    private static boolean isWaterloggedBlock(BlockState state)
    {
        return state.hasProperty(BlockStateProperties.WATERLOGGED) &&
               state.getValue(BlockStateProperties.WATERLOGGED);
    }

    private static BlockState getBaseBlockState(BlockState state)
    {
        if (state.hasProperty(BlockStateProperties.WATERLOGGED))
        {
            return state.setValue(BlockStateProperties.WATERLOGGED, false);
        }
        return state;
    }
}

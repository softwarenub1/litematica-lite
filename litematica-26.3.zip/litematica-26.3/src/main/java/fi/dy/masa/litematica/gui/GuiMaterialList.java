package fi.dy.masa.litematica.gui;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;

import fi.dy.masa.malilib.config.IConfigOptionList;
import fi.dy.masa.malilib.config.IConfigOptionListEntry;
import fi.dy.masa.malilib.data.DataDump;
import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.GuiListBase;
import fi.dy.masa.malilib.gui.GuiTextFieldInteger;
import fi.dy.masa.malilib.gui.Message.MessageType;
import fi.dy.masa.malilib.gui.button.*;
import fi.dy.masa.malilib.gui.interfaces.ITextFieldListener;
import fi.dy.masa.malilib.gui.widgets.WidgetInfoIcon;
import fi.dy.masa.malilib.gui.wrappers.TextFieldType;
import fi.dy.masa.malilib.interfaces.ICompletionListener;
import fi.dy.masa.malilib.util.FileUtils;
import fi.dy.masa.malilib.util.GuiUtils;
import fi.dy.masa.malilib.util.StringUtils;
import fi.dy.masa.malilib.util.data.ItemType;
import fi.dy.masa.malilib.util.input.ScanCodes;
import fi.dy.masa.malilib.util.time.TimeFormat;
import fi.dy.masa.litematica.Reference;
import fi.dy.masa.litematica.config.Configs;
import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.gui.GuiMainMenu.ButtonListenerChangeMenu;
import fi.dy.masa.litematica.gui.widgets.WidgetListMaterialList;
import fi.dy.masa.litematica.gui.widgets.WidgetMaterialListEntry;
import fi.dy.masa.litematica.materials.*;
import fi.dy.masa.litematica.materials.json.MaterialListJson;
import fi.dy.masa.litematica.materials.json.MaterialListJsonCache;
import fi.dy.masa.litematica.render.infohud.InfoHud;
import fi.dy.masa.litematica.util.BlockInfoListType;

public class GuiMaterialList extends GuiListBase<MaterialListEntry, WidgetMaterialListEntry, WidgetListMaterialList>
                             implements ICompletionListener
{
    private final MaterialListBase materialList;
    private ExportType exportType = ExportType.WRITE_TO_FILE;
    private boolean isNarrow;

    public GuiMaterialList(MaterialListBase materialList)
    {
        super(10, 44);

        this.materialList = materialList;
        this.materialList.setCompletionListener(this);
        this.title = this.materialList.getTitle();
        this.useTitleHierarchy = false;

        MaterialListUtils.updateAvailableCounts(this.materialList.getMaterialsAll(), this.mc.player);
        WidgetMaterialListEntry.setMaxNameLength(materialList.getMaterialsAll(), materialList.getMultiplier());

        // Remember the last opened material list, for the hotkey
        if (DataManager.getMaterialList() == null)
        {
            DataManager.setMaterialList(materialList);
        }
    }

    @Override
    protected int getBrowserWidth()
    {
        return this.getScreenWidth() - 20;
    }

    @Override
    protected int getBrowserHeight()
    {
        return this.getScreenHeight() - 80;
    }

    @Override
    public void initGui()
    {
        super.initGui();

        this.createMultiplier();
        this.createButtons();
        this.createCounts();
    }

    private void createMultiplier()
    {
        int y = 24;
        String str = StringUtils.translate("litematica.gui.label.material_list.multiplier");
        int w = this.getStringWidth(str);
        this.addLabel(this.getScreenWidth() - w - 56, y + 5, w, 12, 0xFFFFFFFF, str);

        GuiTextFieldInteger tf = new GuiTextFieldInteger(this.getScreenWidth() - 52, y + 2, 40, 16, this.font);
        tf.setValueWrapper(String.valueOf(this.materialList.getMultiplier()));
        MultiplierListener listener = new MultiplierListener(this.materialList, this);
        this.addTextField(tf, listener, TextFieldType.STRING);

        this.addWidget(new WidgetInfoIcon(this.getScreenWidth() - 23, 10, Icons.INFO_11, "litematica.info.material_list"));
    }

    private void createButtons()
    {
        this.isNarrow = this.getScreenWidth() < this.getElementTotalWidth();
        int x = 12;
        int y = 24;
        int buttonWidth;
        String label;
        ButtonGeneric button;

        int gap = 1;
        x += this.createButton(x, y, ButtonListener.Type.REFRESH_LIST) + gap;

        if (this.materialList.supportsRenderLayers())
        {
            x += this.createButton(x, y, ButtonListener.Type.LIST_TYPE) + gap;
        }

        x += this.createButtonOnOff(x, y, -1, this.materialList.getHideAvailable(), ButtonListener.Type.HIDE_AVAILABLE) + gap;
        x += this.createButtonOnOff(x, y, -1, this.materialList.getHudRenderer().getShouldRenderCustom(), ButtonListener.Type.TOGGLE_INFO_HUD) + gap;

        if (this.isNarrow)
        {
            x = 12;
            y = this.getScreenHeight() - 22;
        }

        x += this.createButton(x, y, ButtonListener.Type.CLEAR_IGNORED) + gap;
        x += this.createButton(x, y, ButtonListener.Type.CLEAR_CACHE) + gap;
        x += this.createButton(x, y, ButtonListener.Type.EXPORT) + gap;
        x += this.createButton(x, y, ButtonListener.Type.EXPORT_TYPE) + gap;
        y += 22;

        y = this.getScreenHeight() - 36;
        ButtonListenerChangeMenu.ButtonType type = ButtonListenerChangeMenu.ButtonType.MAIN_MENU;
        label = StringUtils.translate(type.getLabelKey());
        buttonWidth = this.getStringWidth(label) + 20;
        x = this.getScreenWidth() - buttonWidth - 10;
        button = new ButtonGeneric(x, y, buttonWidth, 20, label);
        this.addButton(button, new ButtonListenerChangeMenu(type, this.getParent()));
    }

    private void createCounts()
    {
        // Progress: Done xx % / Missing xx % / Wrong xx %
        long total = this.materialList.getCountTotal();
        long missing = this.materialList.getCountMissing() - this.materialList.getCountMismatched();
        long mismatch = this.materialList.getCountMismatched();

        if (total != 0 && (this.materialList instanceof MaterialListAreaAnalyzer) == false)
        {
            double pctDone = ((double) (total - (missing + mismatch)) / (double) total) * 100;
            double pctMissing = ((double) missing / (double) total) * 100;
            double pctMismatch = ((double) mismatch / (double) total) * 100;
            String str;
            String strp;
            String strt = StringUtils.translate("litematica.gui.label.material_list.total", total);
            int w;

            if (missing == 0 && mismatch == 0)
            {
                strp = StringUtils.translate("litematica.gui.label.material_list.progress.done", String.format("%.0f %%%%", pctDone));
            }
            else
            {
                String str1 = StringUtils.translate("litematica.gui.label.material_list.progress.done", String.format("%.1f %%%%", pctDone));
                String str2 = StringUtils.translate("litematica.gui.label.material_list.progress.missing", String.format("%.1f %%%%", pctMissing));
                String str3 = StringUtils.translate("litematica.gui.label.material_list.progress.mismatch", String.format("%.1f %%%%", pctMismatch));
                strp = String.format("%s / %s / %s", str1, str2, str3);
            }

            str = strt + " / " + StringUtils.translate("litematica.gui.label.material_list.progress", strp);
            w = this.getStringWidth(str);
            this.addLabel(12, this.getScreenHeight() - 36, w, 12, 0xFFFFFFFF, str);
        }

        if (this.mc.player == null)
        {
            this.addMessage(MessageType.WARNING, 3000, "litematica.message.warn.material_list.no_player_inv");
        }
    }

    private int createButton(int x, int y, ButtonListener.Type type)
    {
        ButtonGeneric button;
        int buttonWidth;

        if (type == ButtonListener.Type.EXPORT_TYPE)
        {
            buttonWidth = this.getStringWidth(this.exportType.getDisplayName()) + 10;
            button = new ConfigButtonOptionList(x, y, buttonWidth, 20, new ExportTypeWrapper());

            if (this.exportType.getHoverText() != null)
            {
                button.setHoverStrings(this.exportType.getHoverText());
            }
        }
        else
        {
            String label = type.getDisplayName();
            String hover = type.getHoverText();

            if (type == ButtonListener.Type.LIST_TYPE)
            {
                label = type.getDisplayName(this.materialList.getMaterialListType().getDisplayName());
            }

            buttonWidth = this.getStringWidth(label) + 10;

            if (hover != null)
            {
                button = new ButtonGeneric(x, y, buttonWidth, 20, label, hover);
            }
            else
            {
                button = new ButtonGeneric(x, y, buttonWidth, 20, label);
            }
        }

        this.addButton(button, new ButtonListener(type, this));

        return button.getWidth();
    }

    private int getElementTotalWidth()
    {
        int width = 0;

        width += this.getStringWidth(ButtonListener.Type.REFRESH_LIST.getDisplayName());
        width += this.getStringWidth(ButtonListener.Type.LIST_TYPE.getDisplayName(this.materialList.getMaterialListType().getDisplayName()));
        width += this.getStringWidth(ButtonListener.Type.CLEAR_IGNORED.getDisplayName());
        width += this.getStringWidth(ButtonListener.Type.CLEAR_CACHE.getDisplayName());
        width += this.getStringWidth(ButtonListener.Type.EXPORT.getDisplayName());
        width += this.getStringWidth(this.exportType.getDisplayName());
        width += (new ButtonOnOff(0, 0, -1, false, ButtonListener.Type.HIDE_AVAILABLE.getTranslationKey(), false)).getWidth();
        width += (new ButtonOnOff(0, 0, -1, false, ButtonListener.Type.TOGGLE_INFO_HUD.getTranslationKey(), false)).getWidth();
        width += this.getStringWidth(StringUtils.translate("litematica.gui.label.material_list.multiplier"));
        width += 130;

        return width;
    }

    private int createButtonOnOff(int x, int y, int width, boolean isCurrentlyOn, ButtonListener.Type type)
    {
        ButtonOnOff button = new ButtonOnOff(x, y, width, false, type.getTranslationKey(), isCurrentlyOn);
        this.addButton(button, new ButtonListener(type, this));
        return button.getWidth();
    }

    public MaterialListBase getMaterialList()
    {
        return this.materialList;
    }

    @Override
    public void onTaskCompleted()
    {
        // re-create the list widgets when a material list task finishes
        if (GuiUtils.getCurrentScreen() == this)
        {
            WidgetMaterialListEntry.setMaxNameLength(this.materialList.getMaterialsAll(), this.materialList.getMultiplier());
            this.initGui();
        }
    }

    @Override
    protected WidgetListMaterialList createListWidget(int listX, int listY)
    {
        return new WidgetListMaterialList(listX, listY, this.getBrowserWidth(), this.getBrowserHeight(), this);
    }

    private class ExportTypeWrapper implements IConfigOptionList
    {
        @Override
        public IConfigOptionListEntry getOptionListValue()
        {
            return GuiMaterialList.this.exportType;
        }

        @Override
        public IConfigOptionListEntry getDefaultOptionListValue()
        {
            return ExportType.WRITE_TO_FILE;
        }

        @Override
        public void setOptionListValue(IConfigOptionListEntry value)
        {
            GuiMaterialList.this.exportType = (GuiMaterialList.ExportType) value;
            GuiMaterialList.this.clearButtons();
            GuiMaterialList.this.createButtons();
        }
    }

    private record ButtonListener(Type type, GuiMaterialList parent) implements IButtonActionListener
    {
        @Override
        public void actionPerformedWithButton(ButtonBase button, int mouseButton)
        {
            MaterialListBase materialList = this.parent.materialList;

            switch (this.type)
            {
                case REFRESH_LIST:
                    materialList.reCreateMaterialList();
                    break;

                case LIST_TYPE:
                    BlockInfoListType type = materialList.getMaterialListType();
                    materialList.setMaterialListType((BlockInfoListType) type.cycle(mouseButton == ScanCodes.OFFSET_MOUSE_LEFT));
                    materialList.reCreateMaterialList();
                    break;

                case HIDE_AVAILABLE:
                    materialList.setHideAvailable(!materialList.getHideAvailable());
                    materialList.refreshPreFilteredList();
                    materialList.recreateFilteredList();
                    break;

                case TOGGLE_INFO_HUD:
                    MaterialListHudRenderer renderer = materialList.getHudRenderer();
                    renderer.toggleShouldRender();

                    if (materialList.getHudRenderer().getShouldRenderCustom())
                    {
                        InfoHud.getInstance().addInfoHudRenderer(renderer, true);
                    }
                    else
                    {
                        InfoHud.getInstance().removeInfoHudRenderersOfType(renderer.getClass(), true);
                    }

                    break;

                case CLEAR_IGNORED:
                    materialList.clearIgnored();
                    break;

                case CLEAR_CACHE:
                    MaterialCache.getInstance().clearCache();
                    this.parent.addMessage(MessageType.SUCCESS, 3000, "litematica.message.material_list.material_cache_cleared");
                    break;

                case EXPORT:
                    if (this.parent.exportType == ExportType.WRITE_TO_FILE)
                    {
                        Path dir = FileUtils.getConfigDirectory().resolve(Reference.MOD_ID);
                        boolean csv = GuiBase.isShiftDown();
                        boolean json = GuiBase.isAltDown();
                        Path file;

                        if (json)
                        {
                            MaterialListJsonExporter exporter = new MaterialListJsonExporter(materialList);
                            String fileName = "material_list_" + TimeFormat.REGULAR.formatNow() + ".json";

                            file = dir.resolve(fileName);

                            if (!exporter.writeCacheToFile(file, TimeFormat.RFC1123, Minecraft.getInstance()))
                            {
                                file = null;
                            }
                        }
                        else
                        {
                            String ext = csv ? ".csv" : ".txt";
                            file = DataDump.dumpDataToFile(dir, "material_list", ext, this.getMaterialListDump(materialList, csv).getLines());
                        }

                        if (file != null)
                        {
                            String key = "litematica.message.material_list_written_to_file";
                            this.parent.addMessage(MessageType.SUCCESS, key, file.getFileName().toString());

                            if (this.parent.mc.player != null)
                            {
                                StringUtils.sendOpenFileChatMessage(this.parent.mc.player, key, file.toFile());
                            }
                        }

                        break;
                    }
                    else if (this.parent.exportType == ExportType.WRITE_TO_JSON)
                    {
                        Minecraft mc = Minecraft.getInstance();
                        Path jsonDir = FileUtils.getConfigDirectory().resolve(Reference.MOD_ID);
                        boolean missingOnly = GuiBase.isShiftDown();
                        boolean craftingOnly = GuiBase.isAltDown();
                        final String dateExt = "_" + TimeFormat.REGULAR.formatNow();
                        String fileName = "raw_material_list_recipe_details" + (missingOnly ? "_missing_only" : "") + dateExt;
                        MaterialListJson jsonWriter = new MaterialListJson();
                        Path jsonFile = jsonDir.resolve(fileName + ".json");
                        MaterialListJsonCache cache = new MaterialListJsonCache();

                        if (!this.getMaterialListForJson(materialList, jsonWriter, cache, missingOnly, craftingOnly))
                        {
                            String key = "litematica.message.error.json_material_list_copy_failure";
                            this.parent.addMessage(MessageType.ERROR, key, jsonFile.getFileName().toString());
                            cache.clearAll();
                            jsonWriter.clear();
                            break;
                        }

                        if (Configs.Generic.MATERIAL_LIST_RECIPE_DETAILS.getBooleanValue() &&
                            !jsonWriter.writeRecipeDetailJson(jsonFile, mc))
                        {
                            String key = "litematica.message.error.json_material_list_failure";
                            this.parent.addMessage(MessageType.ERROR, key, jsonFile.getFileName().toString());
                            cache.clearAll();
                            jsonWriter.clear();
                            break;
                        }

                        fileName = "raw_material_list_recipe_steps" + (missingOnly ? "_missing_only" : "") + dateExt;
                        jsonFile = jsonDir.resolve(fileName + ".json");

                        if (!jsonWriter.writeCacheFlatJson(cache, jsonFile, mc))
                        {
                            String key = "litematica.message.error.json_material_list_failure";
                            this.parent.addMessage(MessageType.ERROR, key, jsonFile.getFileName().toString());
                            cache.clearAll();
                            jsonWriter.clear();
                            break;
                        }

                        fileName = "raw_material_list_simplified" + (missingOnly ? "_missing_only" : "") + dateExt;
                        jsonFile = jsonDir.resolve(fileName + ".json");

                        if (jsonWriter.writeCacheCombinedJson(cache, jsonFile, mc))
                        {
                            String key = "litematica.message.material_list_written_to_json_file";
                            this.parent.addMessage(MessageType.SUCCESS, key, jsonFile.getFileName().toString());
                            if (this.parent.mc.player != null)
                            {
                                StringUtils.sendOpenFileChatMessage(this.parent.mc.player, key, jsonFile.toFile());
                            }
                        }
                        else
                        {
                            String key = "litematica.message.error.json_material_list_failure";
                            this.parent.addMessage(MessageType.ERROR, key, jsonFile.getFileName().toString());
                        }

                        cache.clearAll();
                        jsonWriter.clear();
                    }
                    else if (this.parent.exportType == ExportType.CUSTOM_JSON)
                    {
                        MaterialListCustom customList = this.getMaterialListCustom(materialList);
                        GuiMaterialListSave gui = new GuiMaterialListSave(customList);
                        gui.setParent(GuiUtils.getCurrentScreen());
                        GuiBase.openGui(gui);
                    }

                    break;
            }

            this.parent.initGui(); // Re-create buttons/text fields
        }

        private MaterialListCustom getMaterialListCustom(MaterialListBase materialList)
        {
            Object2IntOpenHashMap<ItemType> items = new Object2IntOpenHashMap<>();

            for (MaterialListEntry entry : materialList.getMaterialsAll())
            {
                ItemStack stack = entry.getStack();
                ItemType itemType = new ItemType(stack, false, false);
                items.put(itemType, entry.getCountTotal());
            }

            return new MaterialListCustom(materialList.getName(), items, null);
        }

        private DataDump getMaterialListDump(MaterialListBase materialList, boolean csv)
        {
            DataDump dump = new DataDump(6, csv ? DataDump.Format.CSV : DataDump.Format.ASCII);
            int multiplier = materialList.getMultiplier();

            ArrayList<MaterialListEntry> list = new ArrayList<>(materialList.getMaterialsFiltered(false));
            list.sort(new MaterialListSorter(materialList));

            for (MaterialListEntry entry : list)
            {
                int stackSize = entry.getStack().getMaxStackSize();
                int total = entry.getCountTotal() * multiplier;
                int missing = multiplier > 1 ? total : entry.getCountMissing();
                int available = entry.getCountAvailable();
                double boxTotal = (double) total / (27D * stackSize);
                double boxMissing = (double) missing / (27D * stackSize);
                dump.addData(entry.getStack().getHoverName().getString(),
                             String.valueOf(total), String.valueOf(missing), String.valueOf(available),
                             String.format("%.02f SB", boxTotal), String.format("%.02f SB", boxMissing)
                );
            }

            String titleTotal = multiplier > 1 ? String.format("Total (x%d)", multiplier) : "Total";
            dump.addTitle("Item", titleTotal, "Missing", "Available", "Total (sb)", "Missing (sb)");
            dump.addHeader(materialList.getTitle());
            dump.setColumnProperties(1, DataDump.Alignment.RIGHT, true); // total
            dump.setColumnProperties(2, DataDump.Alignment.RIGHT, true); // missing
            dump.setColumnProperties(3, DataDump.Alignment.RIGHT, true); // available
            dump.setColumnProperties(4, DataDump.Alignment.RIGHT, false); // boxTotal
            dump.setColumnProperties(5, DataDump.Alignment.RIGHT, false); // boxMissing
            dump.setSort(false);
            dump.setUseColumnSeparator(true);

            return dump;
        }

        private boolean getMaterialListForJson(MaterialListBase materialList, MaterialListJson jsonWriter, MaterialListJsonCache cache, boolean missingOnly, boolean craftingOnly)
        {
            if (missingOnly)
            {
                return jsonWriter.readMaterialListMissingOnly(materialList, cache, craftingOnly);
            }
            else
            {
                return jsonWriter.readMaterialListAll(materialList, cache, craftingOnly);
            }
        }

        public enum Type
        {
            REFRESH_LIST        ("litematica.gui.button.material_list.refresh_list"),
            LIST_TYPE           ("litematica.gui.button.material_list.list_type"),
            HIDE_AVAILABLE      ("litematica.gui.button.material_list.hide_available"),
            TOGGLE_INFO_HUD     ("litematica.gui.button.material_list.toggle_info_hud"),
            CLEAR_IGNORED       ("litematica.gui.button.material_list.clear_ignored"),
            CLEAR_CACHE         ("litematica.gui.button.material_list.clear_cache", "litematica.gui.button.hover.material_list.clear_cache"),
            EXPORT              ("litematica.gui.button.material_list.export",      "litematica.gui.button.hover.material_list.export_as"),
            EXPORT_TYPE         (""),
            ;

            private final String translationKey;
            @Nullable
            private final String hoverText;

            Type(String label)
            {
                this(label, null);
            }

            Type(String label, @Nullable String hoverText)
            {
                this.translationKey = label;
                this.hoverText = hoverText;
            }

            public String getTranslationKey()
            {
                return this.translationKey;
            }

            public String getDisplayName(Object... args)
            {
                return StringUtils.translate(this.translationKey, args);
            }

            @Nullable
            public String getHoverText()
            {
                return this.hoverText != null ? StringUtils.translate(this.hoverText) : null;
            }
        }
    }

    private record MultiplierListener(MaterialListBase materialList, GuiMaterialList gui)
            implements ITextFieldListener<GuiTextFieldInteger>
    {
        @Override
        public boolean onTextChange(GuiTextFieldInteger textField)
        {
            try
            {
                int multiplier = Integer.parseInt(textField.getValueWrapper());

                if (multiplier != this.materialList.getMultiplier())
                {
                    this.materialList.setMultiplier(multiplier);
                    this.gui.getListWidget().refreshEntries();
                    return true;
                }
            }
            catch (Exception e)
            {
                this.materialList.setMultiplier(1);
                this.gui.getListWidget().refreshEntries();
            }

            return false;
        }
    }

    public enum ExportType implements IConfigOptionListEntry
    {
        WRITE_TO_FILE       ("litematica.gui.button.material_list.write_to_file",       "litematica.gui.button.hover.material_list.write_hold_shift_for_csv"),
        WRITE_TO_JSON       ("litematica.gui.button.material_list.write_to_json",       "litematica.gui.button.hover.material_list.json_hold_shift_for_missing_only"),
        CUSTOM_JSON         ("litematica.gui.button.material_list.export_custom_json",  "litematica.gui.button.hover.material_list.export_custom_json"),
        ;

        private final String label;
        private final String hoverText;

        ExportType(String label)
        {
            this(label, null);
        }

        ExportType(String label, @Nullable String hoverText)
        {
            this.label = label;
            this.hoverText = hoverText;
        }

        @Override
        public String getStringValue()
        {
            return this.name().toLowerCase();
        }

        @Override
        public String getDisplayName()
        {
            return StringUtils.translate(this.label);
        }

        @Nullable
        @Override
        public List<String> getHoverText()
        {
            return this.hoverText != null ? List.of(StringUtils.translate(this.hoverText)) : null;
        }

        @Override
        public IConfigOptionListEntry cycle(boolean forward)
        {
            int id = this.ordinal();

            if (forward)
            {
                if (++id >= values().length)
                {
                    id = 0;
                }
            }
            else
            {
                if (--id < 0)
                {
                    id = values().length - 1;
                }
            }

            return values()[id % values().length];
        }

        @Override
        public ExportType fromString(String name)
        {
            return fromStringStatic(name);
        }

        public static ExportType fromStringStatic(String name)
        {
            for (ExportType al : ExportType.values())
            {
                if (al.name().equalsIgnoreCase(name))
                {
                    return al;
                }
            }

            return ExportType.WRITE_TO_FILE;
        }
    }
}

package fi.dy.masa.litematica.schematic.conversion;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

import com.mojang.datafixers.DataFixUtils;
import com.mojang.serialization.Dynamic;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.resources.Identifier;
import net.minecraft.util.datafix.DataFixers;
import net.minecraft.util.datafix.fixes.References;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;

import fi.dy.masa.malilib.util.data.Constants;
import fi.dy.masa.malilib.util.data.tag.CompoundData;
import fi.dy.masa.malilib.util.data.tag.ListData;
import fi.dy.masa.malilib.util.data.tag.converter.DataConverterNbt;
import fi.dy.masa.malilib.util.data.tag.util.DataOps;
import fi.dy.masa.malilib.util.data.tag.util.DataTypeUtils;
import fi.dy.masa.malilib.util.game.BlockUtils;
import fi.dy.masa.litematica.Litematica;
import fi.dy.masa.litematica.config.Configs;
import fi.dy.masa.litematica.schematic.LitematicaSchematic;
import fi.dy.masa.litematica.world.SchematicWorldHandler;

public class SchematicConversionMaps
{
	private static final Object2IntOpenHashMap<String> OLD_BLOCK_NAME_TO_SHIFTED_BLOCK_ID = DataFixUtils.make(new Object2IntOpenHashMap<>(), (map) -> map.defaultReturnValue(-1));
	private static final Int2ObjectOpenHashMap<String> ID_META_TO_UPDATED_NAME = new Int2ObjectOpenHashMap<>();
	private static final Object2IntOpenHashMap<BlockState> BLOCKSTATE_TO_ID_META = DataFixUtils.make(new Object2IntOpenHashMap<>(), (map) -> map.defaultReturnValue(-1));
	private static final Int2ObjectOpenHashMap<BlockState> ID_META_TO_BLOCKSTATE = new Int2ObjectOpenHashMap<>();
	private static final ConcurrentHashMap<String, String> OLD_NAME_TO_NEW_NAME = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, String> NEW_NAME_TO_OLD_NAME = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<CompoundData, CompoundData> OLD_STATE_TO_NEW_STATE = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<CompoundData, CompoundData> NEW_STATE_TO_OLD_STATE = new ConcurrentHashMap<>();
	private static final ArrayList<ConversionData> CACHED_DATA = new ArrayList<>();
	private static final ArrayList<ConversionDynamic> CACHED_DYNAMIC = new ArrayList<>();

	private static boolean initialized;

	public static void addEntry(int idMeta, String newStateString, String... oldStateStrings)
	{
		CACHED_DATA.add(new ConversionData(idMeta, newStateString, oldStateStrings));
	}

	public static void addDynamicEntry(int idMeta, Dynamic<?> newState, List<Dynamic<?>> oldStates)
	{
		CACHED_DYNAMIC.add(new ConversionDynamic(idMeta, newState, oldStates));
	}

	public static void computeMaps()
	{
		if (initialized)
		{
			return;
		}

		clearMaps();
		addOverrides();

		if (!CACHED_DYNAMIC.isEmpty())
		{
			computeMapsDynamic();
		}
		else if (!CACHED_DATA.isEmpty())
		{
			computeMapsLegacy();
		}
		else
		{
			throw new RuntimeException("computeMaps(): No Cached Block State Flattening maps has been cached!");
		}

		initialized = true;
	}

	private static void computeMapsLegacy()
	{
		for (ConversionData data : CACHED_DATA)
		{
			try
			{
				if (data.oldStateStrings.length > 0)
				{
					CompoundData oldStateTag = getStateTagFromString(data.oldStateStrings[0]);

					if (oldStateTag != null)
					{
						String name = oldStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
						OLD_BLOCK_NAME_TO_SHIFTED_BLOCK_ID.putIfAbsent(name, data.idMeta & 0xFFF0);
					}
				}

				CompoundData newStateTag = getStateTagFromString(data.newStateString);

				if (newStateTag != null)
				{
					addIdMetaToBlockState(data.idMeta, newStateTag, data.oldStateStrings);
				}
			}
			catch (Exception e)
			{
				Litematica.LOGGER.warn("computeMapsLegacy(): Exception while adding blockstate conversion map entry for ID '{}' (fixed state: '{}')", data.idMeta, data.newStateString, e);
			}
		}
	}

	private static void computeMapsDynamic()
	{
		for (ConversionDynamic entry : CACHED_DYNAMIC)
		{
			try
			{
				if (!entry.oldStates().isEmpty())
				{
					String oldName = entry.oldStates().getFirst().get(BlockUtils.BLOCK_STATE_NAME).asString("");

					if (!oldName.isEmpty())
					{
						OLD_BLOCK_NAME_TO_SHIFTED_BLOCK_ID.putIfAbsent(oldName, entry.idMeta() & 0xFFF0);
					}
				}

				CompoundData newStateTag = (CompoundData) entry.newState().convert(DataOps.INSTANCE).getValue();

				if (!newStateTag.isEmpty())
				{
					addIdMetaToBlockStateDynamic(entry.idMeta(), newStateTag, entry.oldStates());
				}
			}
			catch (Exception e)
			{
				Litematica.LOGGER.warn("computeMapsDynamic(): Exception while adding blockstate conversion map entry for ID '{}' (fixed state: '{}')", entry.idMeta, entry.newState.toString(), e);
			}
		}
	}

	@Nullable
	public static BlockState get_1_13_2_StateForIdMeta(int idMeta)
	{
		return ID_META_TO_BLOCKSTATE.get(idMeta);
	}

	public static CompoundData get_1_13_2_StateTagFor_1_12_Tag(CompoundData oldStateTag)
	{
		CompoundData tag = OLD_STATE_TO_NEW_STATE.get(oldStateTag);
		return tag != null ? tag : oldStateTag;
	}

	public static CompoundData get_1_12_StateTagFor_1_13_2_Tag(CompoundData newStateTag)
	{
		CompoundData tag = NEW_STATE_TO_OLD_STATE.get(newStateTag);
		return tag != null ? tag : newStateTag;
	}

	public static int getOldNameToShiftedBlockId(String oldBlockname)
	{
		return OLD_BLOCK_NAME_TO_SHIFTED_BLOCK_ID.getInt(oldBlockname);
	}

	private static void addOverrides()
	{
		BlockState air = Blocks.AIR.defaultBlockState();
		BLOCKSTATE_TO_ID_META.put(air, 0);
		ID_META_TO_BLOCKSTATE.put(0, air);

		int idOldLog = (17 << 4) | 12;
		int idNewLog = (162 << 4) | 12;
		ID_META_TO_BLOCKSTATE.put(idOldLog | 0, Blocks.OAK_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
		ID_META_TO_BLOCKSTATE.put(idOldLog | 1, Blocks.SPRUCE_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
		ID_META_TO_BLOCKSTATE.put(idOldLog | 2, Blocks.BIRCH_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
		ID_META_TO_BLOCKSTATE.put(idOldLog | 3, Blocks.JUNGLE_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
		ID_META_TO_BLOCKSTATE.put(idNewLog | 0, Blocks.ACACIA_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));
		ID_META_TO_BLOCKSTATE.put(idNewLog | 1, Blocks.DARK_OAK_WOOD.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Y));

		// These will get converted to the correct type in the state fixers
		ID_META_TO_UPDATED_NAME.put(1648, "minecraft:melon");

		ID_META_TO_UPDATED_NAME.put(2304, "minecraft:skeleton_skull");
		ID_META_TO_UPDATED_NAME.put(2305, "minecraft:skeleton_skull");
		ID_META_TO_UPDATED_NAME.put(2306, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2307, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2308, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2309, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2312, "minecraft:skeleton_skull");
		ID_META_TO_UPDATED_NAME.put(2313, "minecraft:skeleton_skull");
		ID_META_TO_UPDATED_NAME.put(2314, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2315, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2316, "minecraft:skeleton_wall_skull");
		ID_META_TO_UPDATED_NAME.put(2317, "minecraft:skeleton_wall_skull");

		ID_META_TO_UPDATED_NAME.put(3664, "minecraft:shulker_box");
		ID_META_TO_UPDATED_NAME.put(3665, "minecraft:shulker_box");
		ID_META_TO_UPDATED_NAME.put(3666, "minecraft:shulker_box");
		ID_META_TO_UPDATED_NAME.put(3667, "minecraft:shulker_box");
		ID_META_TO_UPDATED_NAME.put(3668, "minecraft:shulker_box");
		ID_META_TO_UPDATED_NAME.put(3669, "minecraft:shulker_box");
	}

	private static void clearMaps()
	{
		OLD_BLOCK_NAME_TO_SHIFTED_BLOCK_ID.clear();
		ID_META_TO_UPDATED_NAME.clear();

		BLOCKSTATE_TO_ID_META.clear();
		ID_META_TO_BLOCKSTATE.clear();

		OLD_NAME_TO_NEW_NAME.clear();
		NEW_NAME_TO_OLD_NAME.clear();

		OLD_STATE_TO_NEW_STATE.clear();
		NEW_STATE_TO_OLD_STATE.clear();
	}

	private static void addIdMetaToBlockState(int idMeta, CompoundData newStateTag, String... oldStateStrings)
	{
		try
		{
			// The flattening map actually has outdated names for some blocks...
			// Ie. some blocks were renamed after the flattening, so we need to handle those here.
			String newName = newStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
			String overriddenName = ID_META_TO_UPDATED_NAME.get(idMeta);

			if (overriddenName != null)
			{
				newName = overriddenName;
				newStateTag.putString(BlockUtils.BLOCK_STATE_NAME, newName);
			}

			//RegistryEntryLookup<Block> lookup = Registries.BLOCK.getReadOnlyWrapper();
//			HolderGetter<Block> lookup = SchematicWorldHandler.INSTANCE.getRegistryManager().lookupOrThrow(Registries.BLOCK);
			// Store the id + meta => state maps before renaming the block for the state <=> state maps
//			BlockState state = net.minecraft.nbt.NbtUtils.readBlockState(lookup, DataConverterNbt.toVanillaCompound(newStateTag));
			BlockState state = DataTypeUtils.readBlockStateFromTag(newStateTag, SchematicWorldHandler.INSTANCE.getRegistryManager());
//			System.out.printf("id: %5d, state: %s, tag: %s\n", idMeta, state, newStateTag);
			ID_META_TO_BLOCKSTATE.putIfAbsent(idMeta, state);

			// Don't override the id and meta for air, which is what unrecognized blocks will turn into
			BLOCKSTATE_TO_ID_META.putIfAbsent(state, idMeta);

			if (oldStateStrings.length > 0)
			{
				CompoundData oldStateTag = getStateTagFromString(oldStateStrings[0]);
				String oldName = oldStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");

				// Don't run the vanilla block rename for overridden names
				if (overriddenName == null)
				{
					newName = updateBlockName(newName, Configs.Generic.DATAFIXER_DEFAULT_SCHEMA.getIntegerValue());
					newStateTag.putString(BlockUtils.BLOCK_STATE_NAME, newName);
				}

				if (oldName.equals(newName) == false)
				{
					OLD_NAME_TO_NEW_NAME.putIfAbsent(oldName, newName);
					NEW_NAME_TO_OLD_NAME.putIfAbsent(newName, oldName);
				}

				addOldStateToNewState(newStateTag, oldStateStrings);
			}
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("addIdMetaToBlockState(): Exception while adding blockstate conversion map entry for ID '{}'", idMeta, e);
		}
	}

	private static void addIdMetaToBlockStateDynamic(int idMeta, CompoundData newStateTag, List<Dynamic<?>> oldStates)
	{
		try
		{
			// The flattening map actually has outdated names for some blocks...
			// Ie. some blocks were renamed after the flattening, so we need to handle those here.
			String newName = newStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
			String overriddenName = ID_META_TO_UPDATED_NAME.get(idMeta);

			if (overriddenName != null)
			{
				newName = overriddenName;
				newStateTag.putString(BlockUtils.BLOCK_STATE_NAME, newName);
			}

			//RegistryEntryLookup<Block> lookup = Registries.BLOCK.getReadOnlyWrapper();
//			HolderGetter<Block> lookup = SchematicWorldHandler.INSTANCE.getRegistryManager().lookupOrThrow(Registries.BLOCK);
			// Store the id + meta => state maps before renaming the block for the state <=> state maps
//			BlockState state = net.minecraft.nbt.NbtUtils.readBlockState(lookup, DataConverterNbt.toVanillaCompound(newStateTag));
			BlockState state = DataTypeUtils.readBlockStateFromTag(newStateTag, SchematicWorldHandler.INSTANCE.getRegistryManager());
//			System.out.printf("id: %5d, state: %s, tag: %s\n", idMeta, state, newStateTag);
			ID_META_TO_BLOCKSTATE.putIfAbsent(idMeta, state);

			// Don't override the id and meta for air, which is what unrecognized blocks will turn into
			BLOCKSTATE_TO_ID_META.putIfAbsent(state, idMeta);

			if (!oldStates.isEmpty())
			{
				String oldName = oldStates.getFirst().get(BlockUtils.BLOCK_STATE_NAME).asString("");

				// Don't run the vanilla block rename for overridden names
				if (overriddenName == null)
				{
					newName = updateBlockName(newName, Configs.Generic.DATAFIXER_DEFAULT_SCHEMA.getIntegerValue());
					newStateTag.putString(BlockUtils.BLOCK_STATE_NAME, newName);
				}

				if (!oldName.equals(newName))
				{
					OLD_NAME_TO_NEW_NAME.putIfAbsent(oldName, newName);
					NEW_NAME_TO_OLD_NAME.putIfAbsent(newName, oldName);
				}

				addOldStateToNewStateDynamic(newStateTag, oldStates);
			}
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("addIdMetaToBlockStateDynamic(): Exception while adding blockstate conversion map entry for ID '{}'", idMeta, e);
		}
	}

	private static void addOldStateToNewState(CompoundData newStateTagIn, String... oldStateStrings)
	{
		try
		{
			// A 1:1 mapping from the old state to the new state
			if (oldStateStrings.length == 1)
			{
				CompoundData oldStateTag = getStateTagFromString(oldStateStrings[0]);

				if (oldStateTag != null)
				{
					OLD_STATE_TO_NEW_STATE.putIfAbsent(oldStateTag, newStateTagIn);
					NEW_STATE_TO_OLD_STATE.putIfAbsent(newStateTagIn, oldStateTag);
				}
			}
			// Multiple old states collapsed into one new state.
			// These are basically states where all the properties were not stored in metadata, but
			// some of the property values were calculated in the getActualState() method.
			else if (oldStateStrings.length > 1)
			{
				CompoundData oldStateTag = getStateTagFromString(oldStateStrings[0]);

				// Same property names and same number of properties - just remap the block name.
				// FIXME Is this going to be correct for everything?
				if (oldStateTag != null && newStateTagIn.getKeys().equals(oldStateTag.getKeys()))
				{
					String oldBlockName = oldStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
					String newBlockName = OLD_NAME_TO_NEW_NAME.get(oldBlockName);

					if (newBlockName != null && newBlockName.equals(oldBlockName) == false)
					{
						for (String oldStateString : oldStateStrings)
						{
							oldStateTag = getStateTagFromString(oldStateString);

							if (oldStateTag != null)
							{
								CompoundData newTag = oldStateTag.copy();
								newTag.putString(BlockUtils.BLOCK_STATE_NAME, newBlockName);

								OLD_STATE_TO_NEW_STATE.putIfAbsent(oldStateTag, newTag);
								NEW_STATE_TO_OLD_STATE.putIfAbsent(newTag, oldStateTag);
							}
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("addOldStateToNewState(): Exception while adding new blockstate to old blockstate conversion map entry for '{}'", newStateTagIn, e);
		}
	}

	private static void addOldStateToNewStateDynamic(CompoundData newStateTagIn, List<Dynamic<?>> oldStates)
	{
		try
		{
			// A 1:1 mapping from the old state to the new state
			if (oldStates.size() == 1)
			{
				CompoundData oldStateTag = new CompoundData();

				try
				{
					oldStateTag = (CompoundData) oldStates.getFirst().convert(DataOps.INSTANCE).getValue();
				}
				catch (Exception err)
				{
					Litematica.LOGGER.warn("addOldStateToNewStateDynamic(): Exception while adding new blockstate to old blockstate conversion map entry for '{}'", newStateTagIn, err);
				}

				if (oldStateTag != null && !oldStateTag.isEmpty())
				{
					OLD_STATE_TO_NEW_STATE.putIfAbsent(oldStateTag, newStateTagIn);
					NEW_STATE_TO_OLD_STATE.putIfAbsent(newStateTagIn, oldStateTag);
				}
			}
			// Multiple old states collapsed into one new state.
			// These are basically states where all the properties were not stored in metadata, but
			// some of the property values were calculated in the getActualState() method.
			else if (oldStates.size() > 1)
			{
				CompoundData oldStateTag = new CompoundData();

				try
				{
					oldStateTag = (CompoundData) oldStates.getFirst().convert(DataOps.INSTANCE).getValue();
				}
				catch (Exception err)
				{
					Litematica.LOGGER.warn("addOldStateToNewStateDynamic(): Exception while adding new blockstate to old blockstate conversion map entry for '{}'", newStateTagIn, err);
				}

				// Same property names and same number of properties - just remap the block name.
				// FIXME Is this going to be correct for everything?
				if (oldStateTag != null && newStateTagIn.getKeys().equals(oldStateTag.getKeys()))
				{
					String oldBlockName = oldStateTag.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
					String newBlockName = OLD_NAME_TO_NEW_NAME.get(oldBlockName);

					if (newBlockName != null && !newBlockName.equals(oldBlockName))
					{
						for (Dynamic<?> entry : oldStates)
						{
//                            oldStateTag = getStateTagFromString(oldStateString);

							try
							{
								oldStateTag = (CompoundData) entry.convert(DataOps.INSTANCE).getValue();
							}
							catch (Exception err)
							{
								Litematica.LOGGER.warn("addOldStateToNewStateDynamic(): Exception while adding new blockstate to old blockstate conversion map entry for '{}'", newStateTagIn, err);
							}

							if (oldStateTag != null)
							{
								CompoundData newTag = oldStateTag.copy();
								newTag.putString(BlockUtils.BLOCK_STATE_NAME, newBlockName);

								OLD_STATE_TO_NEW_STATE.putIfAbsent(oldStateTag, newTag);
								NEW_STATE_TO_OLD_STATE.putIfAbsent(newTag, oldStateTag);
							}
						}
					}
				}
			}
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("addOldStateToNewStateDynamic(): Exception while adding new blockstate to old blockstate conversion map entry for '{}'", newStateTagIn, e);
		}
	}

	public static CompoundData getStateTagFromString(String str)
	{
		try
		{
			return DataConverterNbt.fromVanillaCompound(TagParser.parseCompoundFully(str.replace('\'', '"')));
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public static String updateBlockName(String oldName, int oldVersion)
	{
		StringTag tagStr = StringTag.valueOf(oldName);

		try
		{
			return DataFixers.getDataFixer()
			                 .update(References.BLOCK_NAME, new Dynamic<>(NbtOps.INSTANCE, tagStr), oldVersion, LitematicaSchematic.MINECRAFT_DATA_VERSION)
			                 .getValue().asString()
			                 .orElse(oldName);
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("updateBlockName: failed to update Block Name [{}], preserving original state (data may become lost)", oldName);
			return oldName;
		}
	}

	/**
	 * These are the Vanilla Data Fixer's for the 1.20.x -> 1.20.5 changes
	 */
	public static CompoundData updateBlockStates(CompoundData oldBlockState, int oldVersion)
	{
		// Don't update the name yet if block is pre-flattening
		if (oldVersion >= LitematicaSchematic.MINECRAFT_DATA_VERSION_1_13_2)
		{
			String oldName = oldBlockState.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "");
			String blockName = updateBlockName(oldName, oldVersion);

			if (!oldName.equalsIgnoreCase(blockName))
			{
				oldBlockState.putString(BlockUtils.BLOCK_STATE_NAME, blockName);
//				Litematica.LOGGER.error("updateBlockName: [{}] -> [{}]", oldName, blockName);
			}
		}

		try
		{
			// FIXME -- for some reason this fails as a CompoundData
			CompoundTag oldTags = DataConverterNbt.toVanillaCompound(oldBlockState);
//			CompoundData result = (CompoundData) DataFixers.getDataFixer()
//			                                               .update(References.BLOCK_STATE, new Dynamic<>(DataOps.INSTANCE, oldBlockState), oldVersion, LitematicaSchematic.MINECRAFT_DATA_VERSION)
//			                                               .getValue();
			CompoundTag result = (CompoundTag) DataFixers.getDataFixer()
			                                              .update(References.BLOCK_STATE, new Dynamic<>(NbtOps.INSTANCE, oldTags), oldVersion, LitematicaSchematic.MINECRAFT_DATA_VERSION)
			                                              .getValue();
			return DataConverterNbt.fromVanillaCompound(result);
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("updateBlockStates: failed to update Block State [{}], preserving original state (data may become lost)",
			                       oldBlockState.getStringOrDefault(BlockUtils.BLOCK_STATE_NAME, "?"));
			return oldBlockState;
		}
	}

	public static CompoundData updateBlockEntity(CompoundData oldBlockEntity, int oldVersion)
	{
		try
		{
			// FIXME -- for some reason this fails as a CompoundData
			CompoundTag oldTags = DataConverterNbt.toVanillaCompound(oldBlockEntity);
			CompoundTag result = (CompoundTag) DataFixers.getDataFixer()
			                                .update(References.BLOCK_ENTITY, new Dynamic<>(NbtOps.INSTANCE, oldTags), oldVersion, LitematicaSchematic.MINECRAFT_DATA_VERSION)
			                                .getValue();
			return DataConverterNbt.fromVanillaCompound(result);
		}
		catch (Exception e)
		{
//            BlockPos pos = NbtUtils.readBlockPos(oldBlockEntity);
			BlockPos pos = DataTypeUtils.readBlockPos(oldBlockEntity);
			Litematica.LOGGER.warn("updateBlockEntity: failed to update Block Entity [{}] at [{}], preserving original state (data may become lost)",
			                       oldBlockEntity.getStringOrDefault("id", "?"), pos != null ? pos.toShortString() : "?");
			return oldBlockEntity;
		}
	}

	public static CompoundData updateEntity(CompoundData oldEntity, int oldVersion)
	{
		try
		{
			// FIXME -- for some reason this fails as a CompoundData
			CompoundTag oldTags = DataConverterNbt.toVanillaCompound(oldEntity);
			CompoundTag result = (CompoundTag) DataFixers.getDataFixer()
			                                .update(References.ENTITY, new Dynamic<>(NbtOps.INSTANCE, oldTags), oldVersion, LitematicaSchematic.MINECRAFT_DATA_VERSION)
			                                .getValue();
			return DataConverterNbt.fromVanillaCompound(result);
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("updateEntity: failed to update Entity [{}], preserving original state (data may become lost)",
			                       oldEntity.getStringOrDefault("id", "?"));
			return oldEntity;
		}
	}

	// Fix missing "id" tags.  This seems to be an issue with 1.19.x litematics.
	public static CompoundData checkForIdTag(CompoundData tags, int minecraftDataVersion)
	{
		if (tags.contains("id", Constants.NBT.TAG_STRING))
		{
			return tags;
		}

		if (tags.contains("Id", Constants.NBT.TAG_STRING))
		{
			tags.putString("id", tags.getStringOrDefault("Id", ""));
			return tags;
		}

		// We don't have an "id" tag, let's try to fix it
		if (tags.containsLenient("Bees") || tags.containsLenient("bees"))
		{
			tags.putString("id", "minecraft:beehive");
		}
		else if (tags.containsLenient("TransferCooldown") && tags.containsLenient("Items"))
		{
			tags.putString("id", "minecraft:hopper");
		}
		else if (tags.containsLenient("SkullOwner"))
		{
			tags.putString("id", "minecraft:skull");
		}
		else if (tags.containsLenient("Patterns") || tags.containsLenient("patterns"))
		{
			tags.putString("id", "minecraft:banner");
		}
		else if (tags.containsLenient("Sherds") || tags.containsLenient("sherds"))
		{
			tags.putString("id", "minecraft:decorated_pot");
		}
		else if (tags.containsLenient("last_interacted_slot") && tags.containsLenient("Items"))
		{
			tags.putString("id", "minecraft:chiseled_bookshelf");
		}
		else if (tags.containsLenient("CookTime") && tags.containsLenient("Items"))
		{
			tags.putString("id", "minecraft:furnace");
		}
		else if (tags.containsLenient("RecordItem"))
		{
			tags.putString("id", "minecraft:jukebox");
		}
		else if (tags.containsLenient("Book") || tags.containsLenient("book"))
		{
			tags.putString("id", "minecraft:lectern");
		}
		else if (tags.containsLenient("front_text"))
		{
			tags.putString("id", "minecraft:sign");
		}
		else if (tags.containsLenient("BrewTime") || tags.containsLenient("Fuel"))
		{
			tags.putString("id", "minecraft:brewing_stand");
		}
		else if ((tags.containsLenient("LootTable") && tags.containsLenient("LootTableSeed")) || (tags.containsLenient("hit_direction") || tags.containsLenient("item")))
		{
			tags.putString("id", "minecraft:suspicious_sand");
		}
		else if (tags.containsLenient("SpawnData") || tags.containsLenient("SpawnPotentials"))
		{
			tags.putString("id", "minecraft:spawner");
		}
		else if (tags.containsLenient("normal_config"))
		{
			tags.putString("id", "minecraft:trial_spawner");
		}
		else if (tags.containsLenient("shared_data"))
		{
			tags.putString("id", "minecraft:vault");
		}
		else if (tags.containsLenient("pool") && tags.containsLenient("final_state") && tags.containsLenient("placement_priority"))
		{
			tags.putString("id", "minecraft:jigsaw");
		}
		else if (tags.containsLenient("author") && tags.containsLenient("metadata") && tags.containsLenient("showboundingbox"))
		{
			tags.putString("id", "minecraft:structure_block");
		}
		else if (tags.containsLenient("ExactTeleport") && tags.containsLenient("Age"))
		{
			tags.putString("id", "minecraft:end_gateway");
		}
		else if (tags.containsLenient("Items"))
		{
			tags.putString("id", "minecraft:chest");
		}
		else if (tags.containsLenient("last_vibration_frequency") || tags.containsLenient("listener"))
		{
			tags.putString("id", "minecraft:sculk_sensor");
		}
		else if (tags.containsLenient("warning_level") || tags.containsLenient("listener"))
		{
			tags.putString("id", "minecraft:sculk_shrieker");
		}
		else if (tags.containsLenient("OutputSignal"))
		{
			tags.putString("id", "minecraft:comparator");
		}
		else if (tags.containsLenient("facing") || tags.containsLenient("extending"))
		{
			tags.putString("id", "minecraft:piston");
		}
		else if (tags.containsLenient("x") && tags.containsLenient("y") && tags.containsLenient("z"))
		{
			// Might only have x y z pos
			tags.putString("id", "minecraft:piston");
		}

		// Fix any erroneous Items tags with the null "tag" tag.
		if (tags.containsList("Items", Constants.NBT.TAG_COMPOUND))
		{
			ListData items = fixItemsTag(tags.getList("Items"), minecraftDataVersion);
			tags.put("Items", items);
		}

		return tags;
	}

	// Fix null 'tag' entries.  This seems to be an issue with 1.19.x litematics.
	private static ListData fixItemsTag(ListData items, int minecraftDataVersion)
	{
		ListData newList = new ListData();

		for (int i = 0; i < items.size(); i++)
		{
			CompoundData itemEntry = fixItemTypesFrom1_21_2(items.getCompoundAt(i), minecraftDataVersion);

			if (itemEntry.contains("tag", Constants.NBT.TAG_COMPOUND))
			{
				CompoundData tag = null;
				try
				{
					tag = itemEntry.getCompound("tag");
				}
				catch (Exception ignored)
				{
				}

				// Remove 'tag' if it is set to null
				if (tag == null)
				{
					itemEntry.remove("tag");
				}
				else
				{
					// Fix nested entries if they exist
					if (tag.contains("BlockEntityTag", Constants.NBT.TAG_COMPOUND))
					{
						CompoundData entityEntry = tag.getCompound("BlockEntityTag");

						if (entityEntry.containsList("Items", Constants.NBT.TAG_COMPOUND))
						{
							ListData nestedItems = fixItemsTag(entityEntry.getList("Items"), minecraftDataVersion);
							entityEntry.put("Items", nestedItems);
						}

						tag.put("BlockEntityTag", entityEntry);
					}

					itemEntry.put("tag", tag);
				}
			}

			newList.add(itemEntry);
		}

		return newList;
	}

	private static CompoundData fixItemTypesFrom1_21_2(CompoundData nbt, int minecraftDataVersion)
	{
		if (!nbt.contains("id", Constants.NBT.TAG_STRING))
		{
			return nbt;
		}

		String id = nbt.getStringOrDefault("id", "");
		Identifier newId = null;

		switch (id)
		{
			case "minecraft:pale_oak_boat", "minecraft:poplar_boat" ->
					newId = Identifier.withDefaultNamespace("oak_boat");
			case "minecraft:pale_oak_chest_boat", "minecraft:poplar_chest_boat" ->
					newId = Identifier.withDefaultNamespace("oak_chest_boat");
		}

		if (newId != null)
		{
			nbt.putString("id", newId.toString());
		}

		return nbt;
	}

	public static CompoundData fixEntityTypesFrom1_21_2(CompoundData nbt, int minecraftDataVersion)
	{
		if (!nbt.contains("id", Constants.NBT.TAG_STRING))
		{
			return nbt;
		}

		// Fix any erroneous Items tags with the null "tag" tag.
		if (nbt.containsList("Items", Constants.NBT.TAG_COMPOUND))
		{
			ListData items = fixItemsTag(nbt.getList("Items"), minecraftDataVersion);
			nbt.put("Items", items);
		}

		String id = nbt.getStringOrDefault("id", "");
		Identifier newId = null;
		String type = "";
		boolean boatFix = false;

		switch (id)
		{
			case "minecraft:oak_boat", "minecraft:pale_oak_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "oak";
				boatFix = true;
			}
			case "minecraft:spruce_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "spruce";
				boatFix = true;
			}
			case "minecraft:birch_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "birch";
				boatFix = true;
			}
			case "minecraft:jungle_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "jungle";
				boatFix = true;
			}
			case "minecraft:acacia_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "acacia";
				boatFix = true;
			}
			case "minecraft:cherry_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "cherry";
				boatFix = true;
			}
			case "minecraft:dark_oak_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "dark_oak";
				boatFix = true;
			}
			case "minecraft:mangrove_boat" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "mangrove";
				boatFix = true;
			}
			case "minecraft:bamboo_raft" ->
			{
				newId = Identifier.withDefaultNamespace("boat");
				type = "bamboo";
				boatFix = true;
			}
			case "minecraft:oak_chest_boat", "minecraft:pale_oak_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "oak";
				boatFix = true;
			}
			case "minecraft:spruce_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "spruce";
				boatFix = true;
			}
			case "minecraft:birch_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "birch";
				boatFix = true;
			}
			case "minecraft:jungle_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "jungle";
				boatFix = true;
			}
			case "minecraft:acacia_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "acacia";
				boatFix = true;
			}
			case "minecraft:cherry_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "cherry";
				boatFix = true;
			}
			case "minecraft:dark_oak_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "dark_oak";
				boatFix = true;
			}
			case "minecraft:mangrove_chest_boat" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "mangrove";
				boatFix = true;
			}
			case "minecraft:bamboo_chest_raft" ->
			{
				newId = Identifier.withDefaultNamespace("chest_boat");
				type = "bamboo";
				boatFix = true;
			}
			default ->
			{
				if (id.contains("_chest_boat"))
				{
					newId = Identifier.withDefaultNamespace("chest_boat");
					type = "oak";
					boatFix = true;
				}
				else if (id.contains("_boat"))
				{
					newId = Identifier.withDefaultNamespace("boat");
					type = "oak";
					boatFix = true;
				}
			}
		}

		if (newId != null)
		{
			nbt.putString("id", newId.toString());
		}

		if (boatFix)
		{
			nbt.putString("Type", type);
		}

		return nbt;
	}

	private record ConversionData(int idMeta, String newStateString, String[] oldStateStrings)
	{
	}

	public record ConversionDynamic(int idMeta, Dynamic<?> newState, List<Dynamic<?>> oldStates)
	{
	}
}

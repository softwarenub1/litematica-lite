# Litematica Lite — experimento 01 (Minecraft 26.3)

**NO ES UN MOD TERMINADO NI APROBADO PARA DOGCRAFT. NO INSTALAR EN EL SERVIDOR.**

Esta copia experimental parte del código fuente de Litematica 0.29.2-sakura.1.

## Cambio realizado
- Se quitaron del registro `mixins.litematica.json` las cuatro entradas de mixins de Easy Place.
- Se retiraron del árbol de fuentes las clases de esos mixins.
- El código original restante se conserva para una revisión de dependencias posterior.

## Lo que NO se ha hecho todavía
- No se han eliminado los manejadores de Easy Place en InputHandler, KeyCallbacks, WorldUtils ni las opciones de configuración.
- No se ha auditado exhaustivamente el tráfico de red, impresión, restricciones de colocación ni el resto de funciones.
- No se ha compilado ni probado en Minecraft 26.3.
- No se ha renombrado el identificador del mod, porque todavía depende de clases y recursos del original.

## Próximo paso
Eliminar los caminos de ejecución de Easy Place y las opciones visibles; compilar con JDK 25 y Gradle, y probar en un mundo local. Solo después evaluar el resto de funciones y solicitar autorización explícita al servidor.

## Licencia
Conservar los avisos de copyright y cumplir la licencia LGPLv3 del código original.

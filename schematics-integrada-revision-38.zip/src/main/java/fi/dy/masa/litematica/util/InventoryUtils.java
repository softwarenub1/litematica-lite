package fi.dy.masa.litematica.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import org.jetbrains.annotations.ApiStatus;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import fi.dy.masa.malilib.gui.GuiBase;
import fi.dy.masa.malilib.gui.Message.MessageType;
import fi.dy.masa.malilib.render.InventoryOverlay;
import fi.dy.masa.malilib.render.InventoryOverlayContext;
import fi.dy.masa.malilib.render.InventoryOverlayRefresher;
import fi.dy.masa.malilib.util.EquipmentUtils;
import fi.dy.masa.malilib.util.InfoUtils;
import fi.dy.masa.malilib.util.data.tag.CompoundData;
import fi.dy.masa.malilib.util.data.tag.ListData;
import fi.dy.masa.malilib.util.data.tag.converter.DataConverterNbt;
import fi.dy.masa.malilib.util.game.BlockUtils;
import fi.dy.masa.malilib.util.nbt.NbtInventory;
import fi.dy.masa.malilib.util.nbt.NbtKeys;
import fi.dy.masa.litematica.config.Configs;
import fi.dy.masa.litematica.data.EntityDataManager;
import fi.dy.masa.litematica.world.WorldSchematic;

public class InventoryUtils
{
    private static final List<Integer> PICK_BLOCKABLE_SLOTS = new ArrayList<>();
    private static int nextPickSlotIndex;

    public static void setPickBlockableSlots(String configStr)
    {
        PICK_BLOCKABLE_SLOTS.clear();
        String[] parts = configStr.split(",");

        for (String str : parts)
        {
            try
            {
                int slotNum = Integer.parseInt(str) - 1;

                if (Inventory.isHotbarSlot(slotNum) &&
                    PICK_BLOCKABLE_SLOTS.contains(slotNum) == false)
                {
                    PICK_BLOCKABLE_SLOTS.add(slotNum);
                }
            }
            catch (NumberFormatException ignore) {}
        }
    }

    public static void setPickedItemToHand(ItemStack stack, Minecraft mc)
    {
        if (mc.player == null) return;
        int slotNum = mc.player.getInventory().findSlotMatchingItem(stack);
        setPickedItemToHand(slotNum, stack, mc);
    }

    public static void setPickedItemToHand(int sourceSlot, ItemStack stack, Minecraft mc)
    {
        // Litematica Lite: automatic placement is not supported.
        return;
    }

	/**
	 * Simulates the 'setPickedItemToHand' logic but does not actually swap the item.
	 * @param stack (Reference Stack)
	 * @param mc ()
	 * @return (Slot Number, or -1)
	 */
	public static int getPickedItemHandSlotNoSwap(ItemStack stack, Minecraft mc)
	{
		if (mc.player == null) return -1;
		int slotNum = mc.player.getInventory().findSlotMatchingItem(stack);
		return getPickedItemHandSlotNoSwap(slotNum, stack, mc);
	}

	/**
	 * Simulates the 'setPickedItemToHand' logic but does not actually swap the item.
	 * @param sourceSlot ()
	 * @param stack (Reference Stack)
	 * @param mc ()
	 * @return (Slot Number, or -1)
	 */
	public static int getPickedItemHandSlotNoSwap(int sourceSlot, ItemStack stack, Minecraft mc)
	{
        // Litematica Lite: even the no-swap helper changed the selected hotbar slot.
        return -1;
    }

	/**
	 * Simulates the MaLiLib -> swapItemToMainHand() without actually swapping the item.
	 * @param stackReference ()
	 * @param mc ()
	 * @return (The Slot ID or -1)
	 */
	private static int getMainHandSlotForItem(ItemStack stackReference, Minecraft mc)
	{
		Player player = mc.player;
		if (mc.player == null) return -1;
		boolean isCreative = player.hasInfiniteMaterials();

		if (fi.dy.masa.malilib.util.InventoryUtils.areStacksEqualIgnoreNbt(stackReference, player.getMainHandItem()))
		{
			return -1;
		}

		if (isCreative)
		{
			player.getInventory().setSelectedSlot(player.getInventory().getSuitableHotbarSlot());
			return 36 + player.getInventory().getSelectedSlot();
		}
		else
		{
			return fi.dy.masa.malilib.util.InventoryUtils.findSlotWithItem(player.inventoryMenu, stackReference, true);
		}
	}

    public static void schematicWorldPickBlock(ItemStack stack, BlockPos pos,
                                               Level schematicWorld, Minecraft mc)
    {
        // Litematica Lite: no schematic-driven automatic item selection.
    }

    private static boolean canPickToSlot(Inventory inventory, int slotNum)
    {
        if (PICK_BLOCKABLE_SLOTS.contains(slotNum) == false)
        {
            return false;
        }

        ItemStack stack = inventory.getItem(slotNum);

        if (stack.isEmpty())
        {
            return true;
        }

        return (Configs.Generic.PICK_BLOCK_AVOID_DAMAGEABLE.getBooleanValue() == false ||
                stack.isDamageableItem() == false) &&
               (Configs.Generic.PICK_BLOCK_AVOID_TOOLS.getBooleanValue() == false ||
                (EquipmentUtils.isRegularTool(stack)) == false);
    }

    private static int getPickBlockTargetSlot(Player player)
    {
        if (PICK_BLOCKABLE_SLOTS.isEmpty() || player == null)
        {
            return -1;
        }

        int slotNum = player.getInventory().getSelectedSlot();

        if (canPickToSlot(player.getInventory(), slotNum))
        {
            return slotNum;
        }

        if (nextPickSlotIndex >= PICK_BLOCKABLE_SLOTS.size())
        {
            nextPickSlotIndex = 0;
        }

        for (int i = 0; i < PICK_BLOCKABLE_SLOTS.size(); ++i)
        {
            slotNum = PICK_BLOCKABLE_SLOTS.get(nextPickSlotIndex);

            if (++nextPickSlotIndex >= PICK_BLOCKABLE_SLOTS.size())
            {
                nextPickSlotIndex = 0;
            }

            if (canPickToSlot(player.getInventory(), slotNum))
            {
                return slotNum;
            }
        }

        return -1;
    }

    private static int getEmptyPickBlockableHotbarSlot(Inventory inventory)
    {
        for (int i = 0; i < PICK_BLOCKABLE_SLOTS.size(); ++i)
        {
            int slotNum = PICK_BLOCKABLE_SLOTS.get(i);

            if (Inventory.isHotbarSlot(slotNum))
            {
                ItemStack stack = inventory.getItem(slotNum);

                if (stack.isEmpty())
                {
                    return slotNum;
                }
            }
        }

        return -1;
    }

    public static boolean doesShulkerBoxContainItem(ItemStack stack, ItemStack referenceItem)
    {
        NonNullList<ItemStack> items = fi.dy.masa.malilib.util.InventoryUtils.getStoredItems(stack);

        return doesListContainItem(items, referenceItem);
    }

    public static boolean doesBundleContainItem(ItemStack stack, ItemStack referenceItem)
    {
        NonNullList<ItemStack> items = fi.dy.masa.malilib.util.InventoryUtils.getBundleItems(stack);

        return doesListContainItem(items, referenceItem);
    }

    private static boolean doesListContainItem(NonNullList<ItemStack> items, ItemStack referenceItem)
    {
        if (items.size() > 0)
        {
            for (ItemStack item : items)
            {
                if (fi.dy.masa.malilib.util.InventoryUtils.areStacksEqualIgnoreNbt(item, referenceItem))
                {
                    return true;
                }
            }
        }

        return false;
    }

    public static int findSlotWithBoxWithItem(AbstractContainerMenu container, ItemStack stackReference, boolean reverse)
    {
        final int startSlot = reverse ? container.slots.size() - 1 : 0;
        final int endSlot = reverse ? -1 : container.slots.size();
        final int increment = reverse ? -1 : 1;
        final boolean isPlayerInv = container instanceof InventoryMenu;

        for (int slotNum = startSlot; slotNum != endSlot; slotNum += increment)
        {
            Slot slot = container.slots.get(slotNum);

            if ((isPlayerInv == false || fi.dy.masa.malilib.util.InventoryUtils.isRegularInventorySlot(slot.index, false)) &&
                doesShulkerBoxContainItem(slot.getItem(), stackReference))
            {
                return slot.index;
            }
        }

        return -1;
    }

    /**
     * Get a valid Inventory Object by any means necessary.
     *
     * @param world (Input ClientWorld)
     * @param pos (Pos of the Tile Entity)
     * @return (The result InventoryOverlay.Context | NULL if not obtainable)
     */
    /**
     * Lite: client-world inventory previews must not delegate to external inventory
     * lookup helpers. Read only a block entity already present in the local world.
     * Schematic/server-side worlds retain their original inventory handling.
     */
    private static @Nullable Container getLocallyAvailableInventory(Level world, BlockPos pos)
    {
        if (world instanceof ServerLevel || world instanceof WorldSchematic)
        {
            return fi.dy.masa.malilib.util.InventoryUtils.getInventory(world, pos);
        }

        BlockEntity blockEntity = world.getBlockEntity(pos);
        return blockEntity instanceof Container container ? container : null;
    }

    public static @Nullable InventoryOverlayContext getTargetInventory(Level world, BlockPos pos)
    {
        BlockState state = world.getBlockState(pos);
        Block blockTmp = state.getBlock();
        CompoundData data = new CompoundData();
        BlockEntity be = null;

        if (blockTmp instanceof EntityBlock)
        {
			Optional<NbtInventory> combinedInv = getCombinedInventory(world, pos);
			ListData list = null;

			if (combinedInv.isPresent())
			{
				NbtInventory inventory = combinedInv.get();
				list = inventory.sorted().toDataList(world.registryAccess());
			}

            if (world instanceof ServerLevel || world instanceof WorldSchematic)
            {
                be = world.getChunkAt(pos).getBlockEntity(pos);

                if (be != null)
                {
					data = DataConverterNbt.fromVanillaCompound(be.saveWithFullMetadata(world.registryAccess()));

					if (list != null && !list.isEmpty())
					{
						data.remove(NbtKeys.ITEMS);
						data.put(NbtKeys.ITEMS, list);
					}
                }
            }
            else
            {
                // Lite: inspect the block entity already loaded on the client only.
                be = world.getBlockEntity(pos);
                if (be != null)
                {
                    data = DataConverterNbt.fromVanillaCompound(be.saveWithFullMetadata(world.registryAccess()));
                    if (list != null && !list.isEmpty())
                    {
                        data.remove(NbtKeys.ITEMS);
                        data.put(NbtKeys.ITEMS, list);
                    }
                }
            }

//            Litematica.LOGGER.warn("getTarget():2: pos [{}], be [{}], nbt [{}]", pos.toShortString(), be != null, data != null);
            InventoryOverlayContext ctx = getTargetInventoryFromBlock(world, pos, be, data);

            if (world instanceof WorldSchematic)
            {
                return ctx;
            }

            // Lite: never reuse an inventory preview from a previous read.
            // The block entity may have changed or its chunk may have unloaded.
            if (ctx != null && ctx.inv() != null)
            {
                return ctx;
            }
        }

        return null;
    }

    private static @Nullable InventoryOverlayContext getTargetInventoryFromBlock(Level world, BlockPos pos, @Nullable BlockEntity be, CompoundData data)
    {
        Container inv;

        if (be != null)
        {
            if (data.isEmpty())
            {
				data = DataConverterNbt.fromVanillaCompound(be.saveWithFullMetadata(world.registryAccess()));
            }
            inv = getLocallyAvailableInventory(world, pos);
        }
        else
        {
            if (data.isEmpty())
            {
                // Lite: no network-backed NBT lookup for inventory previews.
                BlockEntity localBe = world.getBlockEntity(pos);
                if (localBe != null)
                {
                    data = DataConverterNbt.fromVanillaCompound(localBe.saveWithFullMetadata(world.registryAccess()));
                }
            }

            inv = getLocallyAvailableInventory(world, pos);
        }

        if (data != null && !data.isEmpty())
        {
            Container inv2 = fi.dy.masa.malilib.util.InventoryUtils.getDataInventory(data, inv != null ? inv.getContainerSize() : -1, world.registryAccess());

            if (inv == null)
            {
                inv = inv2;
            }
        }

//        Litematica.LOGGER.warn("getTarget(): [SchematicWorld? {}] pos [{}], inv [{}], be [{}], nbt [{}]", world instanceof WorldSchematic ? "YES" : "NO", pos.toShortString(), inv != null, be != null, data != null ? data.getString("id") : new CompoundData());

	    if (be == null)
	    {
		    be = world.getBlockEntity(pos);

		    if (inv == null || inv.isEmpty())
		    {
			    if (be instanceof Container cc)
			    {
				    inv = cc;
			    }
		    }
	    }

		// Continue showing nothing when null
        if (inv == null || data == null)
        {
            return null;
        }

        return new InventoryOverlayContext(InventoryOverlay.getBestInventoryType(inv, data), inv, be != null ? be : world.getBlockEntity(pos), null, data, new Refresher());
    }

    // This really isn't used for this use case; but this is just here for Compat
    public static class Refresher implements InventoryOverlayRefresher
    {

        @Override
        public InventoryOverlayContext onContextRefresh(InventoryOverlayContext data, Level world)
        {
            // Refresh data
            if (data.be() != null)
            {
                getTargetInventory(world, data.be().getBlockPos());
                data = getTargetInventoryFromBlock(data.be().getLevel(), data.be().getBlockPos(), data.be(), data.data());
            }
            /*
            else if (data.entity() != null)
            {
                EntitiesDataStorage.getInstance().requestEntity(world, data.entity().getId());
                data = getTargetInventoryFromEntity(data.entity(), data.data());
            }
             */

            return data;
        }
    }

	public static Optional<NbtInventory> getCombinedInventory(Level world, BlockPos pos)
	{
		Container inv;

		inv = getLocallyAvailableInventory(world, pos);

		if (inv != null && inv.getContainerSize() >= NbtInventory.DEFAULT_SIZE)
		{
			return Optional.of(NbtInventory.fromInventory(inv));
		}

		return Optional.empty();
	}

	/**
	 * Converts an NbtCompound representation of an ItemStack into a '/give' compatible string.
	 * This is the format used by the ItemStringReader(), including Data Components.
	 *
	 * @param nbt (Nbt Input, must be valid ItemStack.encode() format)
	 * @return (The String Result | NULL if the NBT is invalid)
	 */
	@Deprecated(forRemoval = true)
	@Nullable
	public static String convertItemNbtToString(CompoundTag nbt)
	{
		StringBuilder result = new StringBuilder();

		if (nbt.isEmpty())
		{
			return null;
		}

		if (nbt.contains("id"))
		{
			result.append(nbt.getStringOr("id", "?"));
		}
		else
		{
			return null;
		}
		if (nbt.contains("components"))
		{
			CompoundTag components = nbt.getCompoundOrEmpty("components");
			int count = 0;

			result.append("[");

			for (String key : components.keySet())
			{
				if (count > 0)
				{
					result.append(", ");
				}

				result.append(key);
				result.append("=");
				result.append(components.get(key));
				count++;
			}

			result.append("]");
		}
		if (nbt.contains("count"))
		{
			int count = nbt.getIntOr("count", 1);

			if (count > 1)
			{
				result.append(" ");
				result.append(count);
			}
		}

		return result.toString();
	}

    /**
     * Post Re-Write Code
     * -
     * Re-stocks more items to the stack in the player's current hotbar slot.
     * @param threshold the number of items at or below which the re-stocking will happen
     * @param allowHotbar whether to allow taking items from other hotbar slots
     */
    @ApiStatus.Experimental
    public static void preRestockHand(Player player,
                                      InteractionHand hand,
                                      int threshold,
                                      boolean allowHotbar)
    {
        // Litematica Lite: automatic inventory restocking is not supported.
        // Keep the method signature for compatibility with existing callers.
    }

    @ApiStatus.Experimental
    public static ItemStack getCursorStack()
    {
        Player player = Minecraft.getInstance().player;
        if (player == null)
        {
            return ItemStack.EMPTY;
        }
        Inventory inv = player.getInventory();
        return inv != null ? inv.getSelectedItem() : ItemStack.EMPTY;
    }

    @ApiStatus.Experimental
    public static int getSelectedHotbarSlot()
    {
        Player player = Minecraft.getInstance().player;
        if (player == null)
        {
            return 0;
        }
        Inventory inv = player.getInventory();
        return inv != null ? inv.getSelectedSlot() : 0;
    }
}

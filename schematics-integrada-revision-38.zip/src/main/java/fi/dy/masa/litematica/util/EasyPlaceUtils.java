package fi.dy.masa.litematica.util;

import java.lang.reflect.Method;
import java.util.*;
import javax.annotation.Nullable;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SwingAnimation;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.*;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import fi.dy.masa.malilib.gui.Message;
import fi.dy.masa.malilib.registry.Registry;
import fi.dy.masa.malilib.util.InfoUtils;
import fi.dy.masa.malilib.util.MessageOutputType;
import fi.dy.masa.malilib.util.game.BlockUtils;
import fi.dy.masa.malilib.util.game.PlacementUtils;
import fi.dy.masa.malilib.util.position.IntBoundingBox;
import fi.dy.masa.malilib.util.position.LayerRange;
import fi.dy.masa.litematica.Litematica;
import fi.dy.masa.litematica.config.Configs;
import fi.dy.masa.litematica.config.Hotkeys;
import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.materials.MaterialCache;
import fi.dy.masa.litematica.mixin.block.IMixinWallMountedBlock;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacementManager;
import fi.dy.masa.litematica.tool.ToolMode;
import fi.dy.masa.litematica.world.SchematicWorldHandler;

/**
 * Post Re-Write Code
 */
public class EasyPlaceUtils
{
    private static final List<PositionCache> EASY_PLACE_POSITIONS = new ArrayList<>();
    private static final HashMap<Block, Boolean> HAS_USE_ACTION_CACHE = new HashMap<>();

    private static boolean isHandling;
    private static boolean isFirstClickEasyPlace;
    private static boolean isFirstClickPlacementRestriction;
	private static long easyPlaceLastPickBlockTime = System.nanoTime();

	public static boolean isHandling()
    {
        return isHandling;
    }

    public static void setHandling(boolean handling)
    {
        isHandling = handling;
    }

	public static double getValidBlockRange(Minecraft mc)
	{
		return Configs.Generic.EASY_PLACE_VANILLA_REACH.getBooleanValue() ? mc.player.blockInteractionRange() : mc.player.blockInteractionRange() + 1.0f;
	}

	public static void setIsFirstClick()
    {
        if (shouldDoEasyPlaceActions())
        {
            isFirstClickEasyPlace = true;
        }

        if (Configs.Generic.PLACEMENT_RESTRICTION.getBooleanValue())
        {
            isFirstClickPlacementRestriction = true;
        }
    }

    private static boolean hasUseAction(Block block)
    {
        Boolean val = HAS_USE_ACTION_CACHE.get(block);

        if (val == null)
        {
            try
            {
                // TODO FIXME cross-MC-version fragile
                String name = Block.class.getSimpleName().equals("Block") ? "useWithoutItem": "a";
                Method method = block.getClass().getMethod(name, BlockState.class, Level.class, BlockPos.class, Player.class, BlockHitResult.class);
                Method baseMethod = Block.class.getMethod(name, BlockState.class, Level.class, BlockPos.class, Player.class, BlockHitResult.class);
                val = method.equals(baseMethod) == false;
            }
            catch (Exception e)
            {
                Litematica.LOGGER.warn("EasyPlaceUtils: Failed to reflect method Block::useWithoutItem", e);
                val = false;
            }

            HAS_USE_ACTION_CACHE.put(block, val);
        }

        return val.booleanValue();
    }

    public static boolean shouldDoEasyPlaceActions()
    {
        // Litematica Lite: automatic placement is not supported.
        return false;
    }

    public static void easyPlaceOnUseTick()
    {
        // Litematica Lite: automatic placement is not supported.
        return;
    }

    public static boolean handleEasyPlaceWithMessage()
    {
        // Litematica Lite: automatic placement is not supported.
        return false;
    }

    public static void onRightClickTail()
    {
        // Litematica Lite: automatic placement is not supported.
        return;
    }

    @Nullable
    private static BlockHitResult getTargetPosition(@Nullable RayTraceUtils.RayTraceWrapper traceWrapper)
    {
        Minecraft mc = Minecraft.getInstance();
        BlockPos overriddenPos = Registry.BLOCK_PLACEMENT_POSITION_HANDLER.getCurrentPlacementPosition();

        if (overriddenPos != null)
        {
            if (mc.player == null)
            {
                return null;
            }
            double reach = mc.player.blockInteractionRange();
            Entity entity = mc.getCameraEntity();
            BlockHitResult trace = RayTraceUtils.traceToPositions(Collections.singletonList(overriddenPos), entity, reach);
            BlockPos pos = overriddenPos;
            Vec3 hitPos;
            Direction side;

            if (trace != null && trace.getType() == HitResult.Type.BLOCK)
            {
                hitPos = trace.getLocation();
                side = trace.getDirection();
            }
            else
            {
                hitPos = new Vec3(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                side = Direction.UP;
            }

            return new BlockHitResult(hitPos, side, pos, false);
        }
        else if (traceWrapper != null && traceWrapper.getHitType() == RayTraceUtils.RayTraceWrapper.HitType.SCHEMATIC_BLOCK)
        {
            //HitResult trace = traceWrapper.getBlockHitResult();
            return traceWrapper.getBlockHitResult();
        }

        return null;
    }

    @Nullable
    private static BlockHitResult getAdjacentClickPosition(final BlockPos targetPos)
    {
        Minecraft mc = Minecraft.getInstance();
        Level world = mc.level;
        if (mc.player == null)
        {
            return null;
        }
        double reach = mc.player.blockInteractionRange();
        Entity entity = mc.getCameraEntity();
        if (entity == null || world == null)
        {
            return null;
        }
        HitResult traceVanilla = fi.dy.masa.malilib.util.game.RayTraceUtils.getRayTraceFromEntity(world, entity, ClipContext.Fluid.NONE, false, reach);

        if (traceVanilla == null)
        {
            return null;
        }

        if (traceVanilla.getType() == HitResult.Type.BLOCK)
        {
            BlockHitResult blockHitResult = (BlockHitResult) traceVanilla;
            BlockPos posVanilla = blockHitResult.getBlockPos();

            // If there is a block in the world right behind the targeted schematic block, then use
            // that block as the click position
            if (PlacementUtils.isReplaceable(world, posVanilla, false) == false &&
                targetPos.equals(posVanilla.relative(blockHitResult.getDirection())))
            {
                return new BlockHitResult(blockHitResult.getLocation(), ((BlockHitResult) traceVanilla).getDirection(), posVanilla, false);
            }
        }

        for (Direction side : Direction.values())
        {
            BlockPos posSide = targetPos.relative(side);

            if (PlacementUtils.isReplaceable(world, posSide, false) == false)
            {
                Vec3 hitPos = getHitPositionForSidePosition(posSide, side);
                //return HitPosition.of(posSide, hitPos, side.getOpposite());
                return new BlockHitResult(hitPos, side.getOpposite(), posSide, false);
            }
        }

        return null;
    }

    private static Vec3 getHitPositionForSidePosition(BlockPos posSide, Direction sideFromTarget)
    {
        Direction.Axis axis = sideFromTarget.getAxis();
        double x = posSide.getX() + 0.5 - sideFromTarget.getStepX() * 0.5;
        double y = posSide.getY() + (axis == Direction.Axis.Y ? (sideFromTarget == Direction.DOWN ? 1.0 : 0.0) : 0.0);
        double z = posSide.getZ() + 0.5 - sideFromTarget.getStepZ() * 0.5;

        return new Vec3(x, y, z);
    }

    @Nullable
    private static BlockHitResult getClickPosition(BlockHitResult targetPosition,
                                                   BlockState stateSchematic,
                                                   BlockState stateClient)
    {
        boolean isSlab = stateSchematic.getBlock() instanceof SlabBlock;

        if (isSlab)
        {
            return getClickPositionForSlab(targetPosition, stateSchematic, stateClient);
        }

        BlockPos targetBlockPos = targetPosition.getBlockPos();
        boolean requireAdjacent = Configs.Generic.EASY_PLACE_CLICK_ADJACENT.getBooleanValue();
//        boolean requireAdjacent = false;

        return requireAdjacent ? getAdjacentClickPosition(targetBlockPos) : targetPosition;
    }

    @Nullable
    private static BlockHitResult getClickPositionForSlab(BlockHitResult targetPosition,
                                                          BlockState stateSchematic,
                                                          BlockState stateClient)
    {
        Minecraft mc = Minecraft.getInstance();
        SlabBlock slab = (SlabBlock) stateSchematic.getBlock();
        BlockPos targetBlockPos = targetPosition.getBlockPos();
        Level worldClient = mc.level;
        boolean isDouble = stateSchematic.getValue(SlabBlock.TYPE).equals(SlabType.DOUBLE);

        if (isDouble)
        {
            if (clientBlockIsSameMaterialSingleSlab(stateSchematic, stateClient))
            {
                boolean isTop = stateClient.getValue(SlabBlock.TYPE) == SlabType.TOP;
                Direction side = isTop ? Direction.DOWN : Direction.UP;
                Vec3 hitPos = targetPosition.getLocation();
                //return HitPosition.of(targetBlockPos, new Vec3d(hitPos.x, targetBlockPos.getY() + 0.5, hitPos.z), side);
                return new BlockHitResult(new Vec3(hitPos.x, targetBlockPos.getY() + 0.5, hitPos.z), side, targetBlockPos, false);
            }
            else if (PlacementUtils.isReplaceable(worldClient, targetBlockPos, true))
            {
                BlockHitResult pos = getClickPositionForSlabHalf(targetPosition, stateSchematic, false, worldClient);
                return pos != null ? pos : getClickPositionForSlabHalf(targetPosition, stateSchematic, true, worldClient);
            }
        }
        // Single slab required, so the target position must be replaceable
        else if (isDouble == false && PlacementUtils.isReplaceable(worldClient, targetBlockPos, true))
        {
            boolean isTop = stateSchematic.getValue(SlabBlock.TYPE) == SlabType.TOP;
            return getClickPositionForSlabHalf(targetPosition, stateSchematic, isTop, worldClient);
        }

        return null;
    }

    @Nullable
    private static BlockHitResult getClickPositionForSlabHalf(BlockHitResult targetPosition, BlockState stateSchematic, boolean isTop, Level worldClient)
    {
        BlockPos targetBlockPos = targetPosition.getBlockPos();
        boolean requireAdjacent = Configs.Generic.EASY_PLACE_CLICK_ADJACENT.getBooleanValue();
//        boolean requireAdjacent = false;

        // Can click on air blocks, check if the slab can be placed by clicking on the target position itself,
        // or if it's a fluid block, then the block above or below, depending on the half
        if (requireAdjacent == false)
        {
            Direction clickSide = isTop ? Direction.DOWN : Direction.UP;
            boolean isReplaceable = PlacementUtils.isReplaceable(worldClient, targetBlockPos, false);

            if (isReplaceable)
            {
                BlockPos posOffset = targetBlockPos.relative(clickSide);
                BlockState stateSide = worldClient.getBlockState(posOffset);

                // Clicking on the target position itself does not create a double slab above or below, so just click on the position itself
                if (clientBlockIsSameMaterialSingleSlab(stateSchematic, stateSide) == false)
                {
                    Vec3 hitPos = targetPosition.getLocation();
                    //return HitPosition.of(targetBlockPos, new Vec3d(hitPos.x, targetBlockPos.getY() + 0.5, hitPos.z), clickSide);
                    return new BlockHitResult(new Vec3(hitPos.x, targetBlockPos.getY() + 0.5, hitPos.z), clickSide, targetBlockPos, false);
                }
            }
            else if (worldClient.getBlockState(targetBlockPos).liquid())
            {
                // Can click on the compensated position without creating a double slab there
                if (canClickOnAdjacentBlockToPlaceSingleSlabAt(targetBlockPos, stateSchematic, clickSide.getOpposite(), worldClient))
                {
                    BlockPos pos = targetBlockPos.relative(clickSide.getOpposite());
                    Vec3 hitPos = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
                    return new BlockHitResult(hitPos, clickSide, pos, false);
                }
            }
        }

        // Required to be clicking on an existing adjacent block,
        // or couldn't click on the target position itself without creating an adjacent double slab
        return getAdjacentClickPositionForSlab(targetBlockPos, stateSchematic, isTop, worldClient);
    }

    @Nullable
    private static BlockHitResult getAdjacentClickPositionForSlab(BlockPos targetBlockPos, BlockState stateSchematic, boolean isTop, Level worldClient)
    {
        Direction clickSide = isTop ? Direction.DOWN : Direction.UP;
        Direction clickSideOpposite = clickSide.getOpposite();
        BlockPos posSide = targetBlockPos.relative(clickSideOpposite);

        // Can click on the existing block above or below
        if (canClickOnAdjacentBlockToPlaceSingleSlabAt(targetBlockPos, stateSchematic, clickSideOpposite, worldClient))
        {
            //return HitPosition.of(posSide, getHitPositionForSidePosition(posSide, clickSideOpposite), clickSide);
            return new BlockHitResult(getHitPositionForSidePosition(posSide, clickSideOpposite), clickSide, posSide, false);
        }
        // Try the sides
        else
        {
            for (Direction side : Direction.values())
            {
                if (canClickOnAdjacentBlockToPlaceSingleSlabAt(targetBlockPos, stateSchematic, side, worldClient))
                {
                    posSide = targetBlockPos.relative(side);
                    Vec3 hitPos = getHitPositionForSidePosition(posSide, side);
                    double y = isTop ? 0.9 : 0.1;
                    //return HitPosition.of(posSide, new Vec3d(hitPos.x, posSide.getY() + y, hitPos.z), side.getOpposite());
                    return new BlockHitResult(new Vec3(hitPos.x, posSide.getY() + y, hitPos.z), side.getOpposite(), posSide, false);
                }
            }
        }

        return null;
    }

    private static boolean canClickOnAdjacentBlockToPlaceSingleSlabAt(BlockPos targetBlockPos, BlockState targetState, Direction side, Level worldClient)
    {
        BlockPos posSide = targetBlockPos.relative(side);
        BlockState stateSide = worldClient.getBlockState(posSide);

        return PlacementUtils.isReplaceable(worldClient, posSide, false) == false &&
               (side.getAxis() != Direction.Axis.Y ||
                clientBlockIsSameMaterialSingleSlab(targetState, stateSide) == false
                || stateSide.getValue(SlabBlock.TYPE) != targetState.getValue(SlabBlock.TYPE));
    }

    private static InteractionResult handleEasyPlace()
    {
        // Litematica Lite: automatic placement is not supported.
        return InteractionResult.PASS;
    }

    private static boolean clientBlockIsSameMaterialSingleSlab(BlockState stateSchematic, BlockState stateClient)
    {
        Block blockSchematic = stateSchematic.getBlock();
        Block blockClient = stateClient.getBlock();

        if ((blockSchematic instanceof SlabBlock) &&
            (blockClient instanceof SlabBlock) &&
            stateClient.getValue(SlabBlock.TYPE).equals(SlabType.DOUBLE) == false)
        {
            SlabType propSchematic = stateSchematic.getValue(SlabBlock.TYPE);
            SlabType propClient = stateClient.getValue(SlabBlock.TYPE);

            return propSchematic == propClient && stateSchematic.getValue(SlabBlock.TYPE) == stateClient.getValue(SlabBlock.TYPE);
        }

        return false;
    }

    private static boolean canPlaceBlock(BlockPos targetPos, Level worldClient, BlockState stateSchematic, BlockState stateClient)
    {
        boolean isSlab = stateSchematic.getBlock() instanceof SlabBlock;

        if (isSlab)
        {
            if (PlacementUtils.isReplaceable(worldClient, targetPos, true) == false &&
                (stateSchematic.getValue(SlabBlock.TYPE).equals(SlabType.DOUBLE) == false
                || clientBlockIsSameMaterialSingleSlab(stateSchematic, stateClient) == false))
            {
                return false;
            }

            return true;
        }

        return PlacementUtils.isReplaceable(worldClient, targetPos, true);
    }

//    private static Vec3 applyCarpetProtocolHitVec(BlockPos pos, BlockState state, Vec3 hitVecIn)
//    {
//        double x = hitVecIn.x;
//        double y = hitVecIn.y;
//        double z = hitVecIn.z;
//        Block block = state.getBlock();
//        Optional<Direction> facingOptional = BlockUtils.getFirstPropertyFacingValue(state);
//
//        if (facingOptional.isPresent())
//        {
//            x = facingOptional.get().ordinal() + 2 + pos.getX();
//        }
//
//        if (block instanceof RepeaterBlock)
//        {
//            x += ((state.getValue(RepeaterBlock.DELAY)) - 1) * 10;
//        }
//        else if (block instanceof TrapDoorBlock && state.getValue(TrapDoorBlock.HALF) == Half.TOP)
//        {
//            x += 10;
//        }
//        else if (block instanceof ComparatorBlock && state.getValue(ComparatorBlock.MODE) == ComparatorMode.SUBTRACT)
//        {
//            x += 10;
//        }
//        else if (block instanceof StairBlock && state.getValue(StairBlock.HALF) == Half.TOP)
//        {
//            x += 10;
//        }
//
//        return new Vec3(x, y, z);
//    }

//    private static Direction applyPlacementFacing(BlockState stateSchematic, Direction side, BlockState stateClient)
//    {
//        Optional<EnumProperty<Direction>> propOptional = BlockUtils.getFirstDirectionProperty(stateSchematic);
//
//        if (propOptional.isPresent())
//        {
//            side = stateSchematic.getValue(propOptional.get()).getOpposite();
//        }
//
//        return side;
//    }

    /**
     * Does placement restriction checks for the targeted position.
     * If the targeted position is outside the current layer range, or should be air
     * in the schematic, or the player is holding the wrong item in hand, then true is returned
     * to indicate that the use action should be canceled.
     */
    public static boolean handlePlacementRestriction()
    {
        boolean cancel = placementRestrictionInEffect();

        if (cancel && isFirstClickPlacementRestriction)
        {
	        MessageOutputType type = (MessageOutputType) Configs.Generic.PLACEMENT_RESTRICTION_WARN.getOptionListValue();
            //MessageOutput output = Configs.InfoOverlays.EASY_PLACE_WARNINGS.getValue();
            //MessageDispatcher.warning(1000).type(output).translate("litematica.message.placement_restriction_fail");

	        if (type ==  MessageOutputType.MESSAGE)
	        {
		        InfoUtils.showInGameMessage(Message.MessageType.WARNING, "litematica.message.placement_restriction_fail");
	        }
			else if (type == MessageOutputType.ACTIONBAR)
	        {
		        InfoUtils.printActionbarMessage("litematica.message.placement_restriction_fail");
	        }
        }

        isFirstClickPlacementRestriction = false;

        return cancel;
    }

    /**
     * Does placement restriction checks for the targeted position.
     * If the targeted position is outside of the current layer range, or should be air
     * in the schematic, or the player is holding the wrong item in hand, then true is returned
     * to indicate that the use action should be cancelled.
     * @return true if the use action should be cancelled
     */
    private static boolean placementRestrictionInEffect()
    {
        Minecraft mc = Minecraft.getInstance();
        Entity entity = mc.getCameraEntity();
        Level world = mc.level;

        if (world == null || entity == null || mc.player == null)
        {
            return false;
        }

        double reach = mc.player.blockInteractionRange();
        HitResult trace = fi.dy.masa.malilib.util.game.RayTraceUtils.getRayTraceFromEntity(world, entity, ClipContext.Fluid.NONE, false, reach);

        if (trace == null)
        {
            return false;
        }

        if (trace.getType() == HitResult.Type.BLOCK)
        {
            BlockHitResult blockHitResult = (BlockHitResult) trace;
            BlockPos pos = blockHitResult.getBlockPos();
            BlockState stateClient = world.getBlockState(pos);

            if (stateClient.canSurvive(world, pos) == false)
            {
                pos = pos.relative(blockHitResult.getDirection());
                stateClient = world.getBlockState(pos);
            }

            // The targeted position is far enough from any schematic sub-regions to not need handling
            if (isPositionWithinRangeOfSchematicRegions(pos, 2) == false)
            {
                return false;
            }

            // Placement position is already occupied
            if (stateClient.canSurvive(world, pos) == false &&
                stateClient.liquid() == false)
            {
                return true;
            }

            Level worldSchematic = SchematicWorldHandler.getSchematicWorld();
            LayerRange range = DataManager.getRenderLayerRange();

            // The targeted position should be air or it's outside the current render range
            if (worldSchematic.isEmptyBlock(pos) || range.isPositionWithinRange(pos) == false)
            {
                return true;
            }

            BlockState stateSchematic = worldSchematic.getBlockState(pos);
            ItemStack stack = MaterialCache.getInstance().getRequiredBuildItemForState(stateSchematic, worldSchematic, pos);

            // The player is holding the wrong item for the targeted position
            return stack.isEmpty() || EntityUtils.getUsedHandForItem(mc.player, stack, true) == null;
        }

        return false;
    }

	static boolean easyPlaceBlockChecksCancel(BlockState stateSchematic, BlockState stateClient,
	                                          Player player, HitResult trace, ItemStack stack)
	{
		Block blockSchematic = stateSchematic.getBlock();

		if (blockSchematic instanceof SlabBlock && stateSchematic.getValue(SlabBlock.TYPE) == SlabType.DOUBLE)
		{
			Block blockClient = stateClient.getBlock();

			if (blockClient instanceof SlabBlock && stateClient.getValue(SlabBlock.TYPE) != SlabType.DOUBLE)
			{
				return blockSchematic != blockClient;
			}
		}

		if (trace.getType() != HitResult.Type.BLOCK)
		{
			return false;
		}

		BlockHitResult hitResult = (BlockHitResult) trace;
		BlockPlaceContext ctx = new BlockPlaceContext(new UseOnContext(player, InteractionHand.MAIN_HAND, hitResult));

		return !stateClient.canBeReplaced(ctx);
	}

	public static class PlacementProtocolData
	{
		boolean handled;
		boolean mustFail;
		BlockPos pos;
		Direction side;
		Vec3 hitVec;
	}

	public static PlacementProtocolData applyPlacementProtocolAll(BlockPos pos, BlockState stateSchematic, Vec3 hitVecIn)
	{
		PlacementProtocolData placementData = new PlacementProtocolData();

		Block stateBlock = stateSchematic.getBlock();
		final Level world = Minecraft.getInstance().level;

		//Wall-mountable blocks
		if (stateBlock instanceof BaseTorchBlock ||
			stateBlock instanceof AbstractBannerBlock ||
			stateBlock instanceof SignBlock ||
			stateBlock instanceof AbstractSkullBlock)
	{
			placementData.handled = true;
			placementData.hitVec = hitVecIn;

			if (stateBlock instanceof WallTorchBlock ||
				stateBlock instanceof RedstoneWallTorchBlock ||
				stateBlock instanceof WallBannerBlock ||
				stateBlock instanceof WallSignBlock ||
				stateBlock instanceof WallSkullBlock)
		{
				placementData.side = stateSchematic.getValue(BlockStateProperties.HORIZONTAL_FACING);
				placementData.pos = pos.relative(placementData.side.getOpposite());
			}
			else
			{
				placementData.side = Direction.UP;
				placementData.pos = pos.below();
			}

			//If the supporting block doesn't exist, fail
			BlockState stateFacing = world.getBlockState(placementData.pos);
			if (stateFacing == null || stateFacing.isAir())
			{
				placementData.mustFail = true;
			}
		}
		else if (stateBlock instanceof FaceAttachedHorizontalDirectionalBlock)
		{
			//If the supporting block doesn't exist, fail
			if (!((IMixinWallMountedBlock)stateBlock).litematica_invokeCanPlaceAt(stateSchematic, world, pos))
				placementData.mustFail = true;
		}

		return placementData;
	}

	/**
	 * Apply the Carpet-Extra mod accurate block placement protocol support
	 */
	public static Vec3 applyCarpetProtocolHitVec(BlockPos pos, BlockState state, Vec3 hitVecIn)
	{
		double x = hitVecIn.x;
		double y = hitVecIn.y;
		double z = hitVecIn.z;
		Block block = state.getBlock();
		Optional<Direction> facing = BlockUtils.getFirstPropertyFacingValue(state);
		final int propertyIncrement = 16;
		boolean hasData = false;
		int protocolValue = 0;

		if (facing.isPresent())
		{
			//System.out.printf("(EasyPlaceUtils):v2: applying: 0x%08X (getFirstDirectionProperty() -> %s)\n", protocolValue, facing.get().getName());

			protocolValue = facing.get().get3DDataValue();
			hasData = true; // without this down rotation would not be detected >_>
		}
		else if (state.hasProperty(BlockStateProperties.AXIS))
		{
			Direction.Axis axis = state.getValue(BlockStateProperties.AXIS);
			//System.out.printf("(EasyPlaceUtils):v2: 0x%08X (current axis %s)\n", protocolValue, axis.getName());

			protocolValue = axis.ordinal();
			hasData = true; // without this id 0 would not be detected >_>
			//System.out.printf("(EasyPlaceUtils):v2: axis current state: %s, protocolValue 0x%08X\n", state.toString(), protocolValue);
		}

		if (block instanceof RepeaterBlock)
		{
			protocolValue += state.getValue(RepeaterBlock.DELAY) * propertyIncrement;
		}
		else if (block instanceof ComparatorBlock && state.getValue(ComparatorBlock.MODE) == ComparatorMode.SUBTRACT)
		{
			protocolValue += propertyIncrement;
		}
		else if (state.hasProperty(BlockStateProperties.HALF) && state.getValue(BlockStateProperties.HALF) == Half.TOP)
		{
			protocolValue += propertyIncrement;
		}
		else if (state.hasProperty(BlockStateProperties.SLAB_TYPE) && state.getValue(BlockStateProperties.SLAB_TYPE) == SlabType.TOP)
		{
			protocolValue += propertyIncrement;
		}

		y = applySlabOrStairHitVecY(y, pos, state);

		if (protocolValue != 0 || hasData)
		{
			x += (protocolValue * 2) + 2;
		}

		//System.out.printf("(EasyPlaceUtils):v2: stateIn: %s // Vec3d Out [%s]\n", state.toString(), new Vec3d(x, y, z).toString());

		return new Vec3(x, y, z);
	}

	private static double applySlabOrStairHitVecY(double origY, BlockPos pos, BlockState state)
	{
		double y = origY;

		if (state.hasProperty(BlockStateProperties.SLAB_TYPE))
		{
			y = pos.getY();

			if (state.getValue(BlockStateProperties.SLAB_TYPE) == SlabType.TOP)
			{
				y += 0.99;
			}
		}
		else if (state.hasProperty(BlockStateProperties.HALF))
		{
			y = pos.getY();

			if (state.getValue(BlockStateProperties.HALF) == Half.TOP)
			{
				y += 0.99;
			}
		}

		return y;
	}

	public static Vec3 applyBlockSlabProtocol(BlockPos pos, BlockState state, Vec3 hitVecIn)
	{
		double newY = applySlabOrStairHitVecY(hitVecIn.y, pos, state);
		return newY != hitVecIn.y ? new Vec3(hitVecIn.x, newY, hitVecIn.z) : hitVecIn;
	}

	public static <T extends Comparable<T>> Vec3 applyPlacementProtocolV3(BlockPos pos, BlockState state, Vec3 hitVecIn)
	{
		Collection<Property<?>> props = state.getBlock().getStateDefinition().getProperties();

		if (props.isEmpty())
		{
			return hitVecIn;
		}

		double relX = hitVecIn.x - pos.getX();
		int protocolValue = 0;
		int shiftAmount = 1;
		int propCount = 0;

		//System.out.printf("(EasyPlaceUtils):v3: hit vec.x %s, pos.x: %s\n", hitVecIn.x(), pos.getX());
		//System.out.printf("(EasyPlaceUtils):v3: raw protocol value in: 0x%08X\n", protocolValue);

		Optional<EnumProperty<Direction>> property = BlockUtils.getFirstDirectionProperty(state);

		// DirectionProperty - allow all except: VERTICAL_DIRECTION (PointedDripstone)
		if (property.isPresent() && property.get() != BlockStateProperties.VERTICAL_DIRECTION)
		{
			Direction direction = state.getValue(property.get());
			protocolValue |= direction.get3DDataValue() << shiftAmount;
			//System.out.printf("(EasyPlaceUtils):v3: applying: 0x%08X (getFirstDirection %s)\n", protocolValue, property.get().getName());
			shiftAmount += 3;
			++propCount;
		}

		List<Property<?>> propList = new ArrayList<>(props);
		propList.sort(Comparator.comparing(Property::getName));

		try
		{
			for (Property<?> p : propList)
			{
				//System.out.printf("(EasyPlaceUtils):v3: check property [%s], whitelisted [%s], blacklisted [%s]\n", p.getName(), PlacementHandler.WHITELISTED_PROPERTIES.contains(p), PlacementHandler.BLACKLISTED_PROPERTIES.contains(p));

				if (property.isPresent() && property.get().equals(p))
				{
					//System.out.printf("(EasyPlaceUtils):v3: skipping prot val: 0x%08X [Property %s]\n", protocolValue, p.getName());
					continue;
				}
				if (PlacementHandler.WHITELISTED_PROPERTIES.contains(p) &&
					!PlacementHandler.BLACKLISTED_PROPERTIES.containsKey(p))
				{
					@SuppressWarnings("unchecked")
					Property<T> prop = (Property<T>) p;
					List<T> list = new ArrayList<>(prop.getPossibleValues());
					list.sort(Comparable::compareTo);

					int requiredBits = Mth.log2(Mth.smallestEncompassingPowerOfTwo(list.size()));
					int valueIndex = list.indexOf(state.getValue(prop));

					//System.out.printf("(EasyPlaceUtils):v3: trying to apply valInd: %d, bits: %d, prot val: 0x%08X [Property %s]\n", valueIndex, requiredBits, protocolValue, prop.getName());

					if (valueIndex != -1)
					{
						//System.out.printf("(EasyPlaceUtils):v3: requesting: %s = %s, index: %d\n", prop.getName(), state.getValue(prop), valueIndex);
						protocolValue |= (valueIndex << shiftAmount);
						shiftAmount += requiredBits;
						++propCount;
					}
				}
				else
				{
					//System.out.printf("(EasyPlaceUtils):v3: skipping prot val: 0x%08X [Property %s]\n", protocolValue, p.getName());
				}
			}
		}
		catch (Exception e)
		{
			Litematica.LOGGER.warn("Exception trying to request placement protocol value", e);
		}

		if (propCount > 0)
		{
			double x = pos.getX() + relX + 2 + protocolValue;
			//System.out.printf("(EasyPlaceUtils):v3: request prot value 0x%08X\n", protocolValue + 2);
			return new Vec3(x, hitVecIn.y, hitVecIn.z);
		}

		return hitVecIn;
	}

	public static Direction applyPlacementFacing(BlockState stateSchematic, Direction side, BlockState stateClient)
	{
		Block blockSchematic = stateSchematic.getBlock();
		Block blockClient = stateClient.getBlock();

		if (blockSchematic instanceof SlabBlock)
		{
			if (stateSchematic.getValue(SlabBlock.TYPE) == SlabType.DOUBLE &&
				blockClient instanceof SlabBlock &&
				stateClient.getValue(SlabBlock.TYPE) != SlabType.DOUBLE)
		{
				if (stateClient.getValue(SlabBlock.TYPE) == SlabType.TOP)
				{
					return Direction.DOWN;
				}
				else
				{
					return Direction.UP;
				}
			}
			// Single slab
			else
			{
				return Direction.NORTH;
			}
		}
		else if (stateSchematic.hasProperty(BlockStateProperties.HALF))
		{
			side = stateSchematic.getValue(BlockStateProperties.HALF) == Half.TOP ? Direction.DOWN : Direction.UP;
		}

		return side;
	}

	/**
	 * Does placement restriction checks for the targeted position.
	 * If the targeted position is outside of the current layer range, or should be air
	 * in the schematic, or the player is holding the wrong item in hand, then true is returned
	 * to indicate that the use action should be cancelled.
	 * @param mc -
	 * @return -
	 */
	public static boolean handlePlacementRestriction(Minecraft mc)
	{
		boolean cancel = placementRestrictionInEffect(mc);

		if (cancel)
		{
			MessageOutputType type = (MessageOutputType) Configs.Generic.PLACEMENT_RESTRICTION_WARN.getOptionListValue();

			if (type == MessageOutputType.MESSAGE)
			{
				InfoUtils.showGuiOrInGameMessage(Message.MessageType.WARNING, "litematica.message.placement_restriction_fail");
			}
			else if (type == MessageOutputType.ACTIONBAR)
			{
				InfoUtils.printActionbarMessage("litematica.message.placement_restriction_fail");
			}
		}

		return cancel;
	}

	/**
	 * Does placement restriction checks for the targeted position.
	 * If the targeted position is outside of the current layer range, or should be air
	 * in the schematic, or the player is holding the wrong item in hand, then true is returned
	 * to indicate that the use action should be cancelled.
	 * @param mc -
	 * @return true if the use action should be cancelled
	 */
	static boolean placementRestrictionInEffect(Minecraft mc)
	{
		HitResult trace = mc.hitResult;

		ItemStack stack = mc.player.getMainHandItem();

		if (stack.isEmpty())
		{
			stack = mc.player.getOffhandItem();
		}

		if (stack.isEmpty())
		{
			return false;
		}

		if (trace != null && trace.getType() == HitResult.Type.BLOCK)
		{
			BlockHitResult blockHitResult = (BlockHitResult) trace;
			BlockPlaceContext ctx = new BlockPlaceContext(new UseOnContext(mc.player, InteractionHand.MAIN_HAND, blockHitResult));

			// Get the possibly offset position, if the targeted block is not replaceable
			BlockPos pos = ctx.getClickedPos();

			BlockState stateClient = mc.level.getBlockState(pos);

			Level worldSchematic = SchematicWorldHandler.getSchematicWorld();
			LayerRange range = DataManager.getRenderLayerRange();
			boolean schematicHasAir = worldSchematic.isEmptyBlock(pos);

			// The targeted position is outside the current render range
			if (schematicHasAir == false && range.isPositionWithinRange(pos) == false)
			{
				return true;
			}

			// There should not be anything in the targeted position,
			// and the position is within or close to a schematic sub-region
			if (schematicHasAir && isPositionWithinRangeOfSchematicRegions(pos, 2))
			{
				return true;
			}

			blockHitResult = new BlockHitResult(blockHitResult.getLocation(), blockHitResult.getDirection(), pos, false);
			ctx = new BlockPlaceContext(new UseOnContext(mc.player, InteractionHand.MAIN_HAND, blockHitResult));

			// Placement position is already occupied
			if (stateClient.canBeReplaced(ctx) == false)
			{
				return true;
			}

			BlockState stateSchematic = worldSchematic.getBlockState(pos);
			stack = MaterialCache.getInstance().getRequiredBuildItemForState(stateSchematic, worldSchematic, pos);

			// The player is holding the wrong item for the targeted position
			if (stack.isEmpty() == false && EntityUtils.getUsedHandForItem(mc.player, stack) == null)
			{
				return true;
			}

			// Ignore if schematic block is wall-mountable and orientation is wrong
			Block schematicBlock = stateSchematic.getBlock();
			if (schematicBlock instanceof WallTorchBlock ||
				schematicBlock instanceof RedstoneWallTorchBlock ||
				schematicBlock instanceof WallBannerBlock ||
				schematicBlock instanceof WallSignBlock ||
				schematicBlock instanceof WallSkullBlock)
			{
				if (blockHitResult.getDirection() != stateSchematic.getValue(BlockStateProperties.HORIZONTAL_FACING))
					return true;
			}

			// Orientation is wrong
			BlockState attemptState = schematicBlock.getStateForPlacement(ctx);
			return !isMatchingStatePlacementRestriction (attemptState, stateSchematic);
		}

		return false;
	}

	private static boolean isMatchingStatePlacementRestriction (BlockState state1, BlockState state2)
	{
		if (state1 == null || state2 == null)
			return false;
		if (state1 == state2)
			return true;

		Property<?>[] orientationProperties = new Property<?>[] {
				BlockStateProperties.FACING, //pistons
				BlockStateProperties.HALF, //stairs, trapdoors
				BlockStateProperties.FACING_HOPPER,
				BlockStateProperties.DOOR_HINGE,
				BlockStateProperties.HORIZONTAL_FACING, //small dripleaf
				BlockStateProperties.AXIS, //logs
				BlockStateProperties.SLAB_TYPE,
				BlockStateProperties.VERTICAL_DIRECTION,
				BlockStateProperties.ROTATION_16, //banners
				BlockStateProperties.HANGING, //lanterns
				BlockStateProperties.ATTACH_FACE, //lever, button, grindstone
				BlockStateProperties.BELL_ATTACHMENT, //bell (double-check for single-wall / double-wall)
				//Properties.HORIZONTAL_AXIS, //Nether portals, though they aren't directly placeable
				//Properties.ORIENTATION, //jigsaw blocks, Crafters
		};

		for (Property<?> property : orientationProperties)
		{
			boolean hasProperty1 = state1.hasProperty(property);
			boolean hasProperty2 = state2.hasProperty(property);

			if (hasProperty1 != hasProperty2)
				return false;
			if (!hasProperty1)
				continue;

			if (state1.getValue(property) != state2.getValue(property))
				return false;
		}

		//Other properties are considered as matching
		return true;
	}

    private static boolean isPositionWithinRangeOfSchematicRegions(BlockPos pos, int range)
    {
        SchematicPlacementManager manager = DataManager.getSchematicPlacementManager();

        final int minCX = (pos.getX() - range) >> 4;
        final int minCY = (pos.getY() - range) >> 4;
        final int minCZ = (pos.getZ() - range) >> 4;
        final int maxCX = (pos.getX() + range) >> 4;
        final int maxCY = (pos.getY() + range) >> 4;
        final int maxCZ = (pos.getZ() + range) >> 4;
        final int x = pos.getX();
        final int y = pos.getY();
        final int z = pos.getZ();

        for (int cy = minCY; cy <= maxCY; ++cy)
        {
            for (int cz = minCZ; cz <= maxCZ; ++cz)
            {
                for (int cx = minCX; cx <= maxCX; ++cx)
                {
                    List<SchematicPlacementManager.PlacementPart> parts = manager.getPlacementPartsInChunk(cx, cz);

                    for (SchematicPlacementManager.PlacementPart part : parts)
                    {
                        IntBoundingBox box = part.bb;

                        if (x >= box.minX() - range && x <= box.maxX() + range &&
                            y >= box.minY() - range && y <= box.maxY() + range &&
                            z >= box.minZ() - range && z <= box.maxZ() + range)
                        {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    protected static boolean easyPlaceIsPositionCached(BlockPos pos)
    {
        long currentTime = System.nanoTime();
        boolean cached = false;

        for (int i = 0; i < EASY_PLACE_POSITIONS.size(); ++i)
        {
            PositionCache val = EASY_PLACE_POSITIONS.get(i);
            boolean expired = val.hasExpired(currentTime);

            if (expired)
            {
                EASY_PLACE_POSITIONS.remove(i);
                --i;
            }
            else if (val.getPos().equals(pos))
            {
                cached = true;

                // Keep checking and removing old entries if there are a fair amount
                if (EASY_PLACE_POSITIONS.size() < 16)
                {
                    break;
                }
            }
        }

        return cached;
    }

	protected static void cacheEasyPlacePosition(BlockPos pos)
    {
        EASY_PLACE_POSITIONS.add(new PositionCache(pos, System.nanoTime(), 2000000000));
    }

    public static class PositionCache
    {
        private final BlockPos pos;
        private final long time;
        private final long timeout;

        private PositionCache(BlockPos pos, long time, long timeout)
        {
            this.pos = pos;
            this.time = time;
            this.timeout = timeout;
        }

        public BlockPos getPos()
        {
            return this.pos;
        }

        public boolean hasExpired(long currentTime)
        {
            return currentTime - this.time > this.timeout;
        }
    }

	protected static boolean easyPlaceIsTooFast()
	{
		return System.nanoTime() - easyPlaceLastPickBlockTime < 1000000L * Configs.Generic.EASY_PLACE_SWAP_INTERVAL.getIntegerValue();
	}

	protected static void setEasyPlaceLastPickBlockTime()
	{
		easyPlaceLastPickBlockTime = System.nanoTime();
	}
}

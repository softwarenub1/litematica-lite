package fi.dy.masa.litematica.scheduler;

import fi.dy.masa.malilib.interfaces.IClientTickHandler;
import net.minecraft.client.Minecraft;
import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.selection.SelectionManager;
import fi.dy.masa.litematica.util.LayerUtils;

public class ClientTickHandler implements IClientTickHandler
{
    @Override
    public void onClientTick(Minecraft mc)
    {
        if (mc.level != null && mc.player != null)
        {
            SelectionManager sm = DataManager.getSelectionManager();

            if (sm.hasGrabbedElement())
            {
                sm.moveGrabbedElement(mc.player);
            }

            // Litematica Lite: no Easy Place tick handling.

            LayerUtils.onClientTick(mc);
            DataManager.getSchematicPlacementManager().onClientTick(mc);
            TaskScheduler.getInstanceClient().runTasks();
        }
    }
}

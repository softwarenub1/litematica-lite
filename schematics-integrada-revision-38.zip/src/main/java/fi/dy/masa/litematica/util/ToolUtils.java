package fi.dy.masa.litematica.util;

import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.block.state.BlockState;
import fi.dy.masa.malilib.interfaces.ICompletionListener;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.selection.AreaSelection;

/** Litematica Lite: editing operations are intentionally disabled. */
public class ToolUtils
{
    public static void fillSelectionVolumes(Minecraft mc, BlockState state, @Nullable BlockState stateToReplace)
    {
        // No-op: never send fill requests or schedule world edits.
    }

    public static void deleteSelectionVolumes(boolean removeEntities, Minecraft mc)
    {
        // No-op.
    }

    public static void deleteSelectionVolumes(@Nullable AreaSelection area, boolean removeEntities, Minecraft mc)
    {
        // No-op.
    }

    public static void deleteSelectionVolumes(@Nullable AreaSelection area, boolean removeEntities,
            @Nullable ICompletionListener listener, Minecraft mc)
    {
        // No-op.
    }

    public static void deleteBlocksByPlacement()
    {
        // No-op.
    }

    public static void deleteBlocksByPlacement(SchematicPlacement placement,
            PlacementDeletionMode mode, @Nullable ICompletionListener listener)
    {
        // No-op.
    }
}
